# Deploying to Hostinger

This guide will help you deploy your CodeIgniter application to a Hostinger domain.

## Prerequisites

1. A Hostinger account with a registered domain name
2. Access to Hostinger's cPanel (or hPanel)
3. This CodeIgniter application

## Step 1: Create a Database

1. Log in to your Hostinger control panel
2. Go to "MySQL Databases" or "Database" section
3. Create a new database (e.g., `yourdomain_geo_rental`)
4. Create a new database user (e.g., `yourdomain_user`) and assign a strong password
5. Add the user to the database with all privileges

## Step 2: Import Database Schema

1. In the Hostinger control panel, go to "phpMyAdmin"
2. Select your newly created database
3. Click on the "Import" tab
4. Upload the `geo_rental_panel.sql` file from this project
5. Click "Go" to import the database schema

## Step 3: Configure Environment Settings

1. Copy the `env` file to `.env` (with a leading dot)
2. Update the database settings in `.env` with your Hostinger database credentials:
   ```
   database.default.hostname = localhost
   database.default.database = yourdomain_geo_rental
   database.default.username = yourdomain_user
   database.default.password = your_password_here
   ```
3. Update the app.baseURL to your actual domain:
   ```
   app.baseURL = 'https://yourdomain.com/'
   ```
4. Ensure CI_ENVIRONMENT is set to 'production'

## Step 4: Upload Files

### Option 1: Using FTP

1. Use an FTP client (like FileZilla) to connect to your Hostinger server
2. Upload all project files to the root directory of your domain (usually public_html)
3. Ensure the `.htaccess` files are also uploaded (they may be hidden files)
4. Make sure the `writable` directory permissions are set to 755 or 775

### Option 2: Using Hostinger File Manager

1. Log in to your Hostinger control panel
2. Go to "File Manager"
3. Navigate to your domain's root directory (usually public_html)
4. Upload a ZIP archive of your project
5. Extract the ZIP archive
6. Set proper permissions:
   - `writable/` directory should be 755 or 775
   - `.env` file should be 644

## Step 5: Final Configuration

1. Ensure proper file permissions:
   ```
   find . -type d -exec chmod 755 {} \;
   find . -type f -exec chmod 644 {} \;
   chmod -R 775 writable/
   ```
2. Clear CodeIgniter caches by deleting files in `writable/cache/` directory
3. Make sure your domain is pointing to the correct directory

## Step 6: Test Your Application

1. Open a web browser and navigate to your domain (e.g., https://yourdomain.com/)
2. Verify that the application works correctly
3. Check for any error messages in the logs at `writable/logs/`

## Troubleshooting

1. If you encounter a "500 Internal Server Error", check the Apache error logs
2. If you see a CodeIgniter error page, ensure your database connection is set up correctly
3. If pages load but functionality doesn't work, check that your .htaccess files are properly uploaded
4. If images or assets don't load, check the paths in your HTML/CSS files

## Additional Notes

- For improved security, place the system and app folders outside of your web root if possible
- Set up SSL through Hostinger's control panel if you haven't already
- Consider setting up automated backups of your database

## Support

If you encounter issues, check the CodeIgniter documentation or contact Hostinger support. 