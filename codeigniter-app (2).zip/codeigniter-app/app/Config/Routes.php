<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('start-plan/(:alpha)', 'Home::startPlan/$1');
$routes->get('login', 'Order::login');
$routes->post('login/authenticate', 'Order::authenticate');
$routes->get('register', 'Order::register');
$routes->post('register/create', 'Order::createAccount');
$routes->get('dashboard', 'Order::dashboard');
$routes->get('logout', 'Order::logout');

// Order routes
$routes->get('/submit-order', 'Order::submitOrder');
$routes->post('/submit-order', 'Order::submitOrder');
$routes->post('/select-payment', 'Order::selectPayment');
$routes->post('/process-order', 'Order::processOrder');
$routes->get('/process-order', 'Order::processOrder');
$routes->post('/process-paypal', 'Order::processPayPal');
$routes->post('/process-stripe', 'Order::processStripe');
$routes->post('/process-account-balance', 'Order::processAccountBalance');
$routes->post('/complete-payment', 'Order::completePayment');
$routes->get('order-confirmation/(:num)', 'Order::confirmation/$1');
// ... existing code ...
// Order routes
$routes->get('/submit-order', 'Order::submitOrder');
$routes->post('/submit-order', 'Order::submitOrder');
$routes->get('/select-payment', 'Order::selectPayment'); // Add this new GET route
$routes->post('/select-payment', 'Order::selectPayment');
$routes->post('/process-order', 'Order::processOrder');
// ... existing code ...

$routes->get('/dashboard', 'Home::dashboard');
$routes->get('/panels', 'Home::panels');
$routes->get('/child-panels', 'Home::childPanels');
$routes->get('/add-fund', 'Home::addFund');
$routes->get('/help', 'Home::help');
$routes->get('/reviews', 'Home::reviews');
$routes->get('/account', 'Home::account');
$routes->get('/affiliate', 'Home::affiliate');


