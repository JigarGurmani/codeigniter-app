<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
        // Check if the user is logged in
        if (session()->get('user')) {
            // If logged in, redirect to dashboard
            return redirect()->to('dashboard');
        }
        
        // If not logged in, show the home page
        $data = [
            'isLoggedIn' => false,
            'title' => 'Welcome to GEO Rental Panel'
        ];
        
        return view('home', $data);
    }
    
    public function startPlan($plan = null)
    {
        // Check if user is logged in
        if (!session()->get('user')) {
            // If not logged in, redirect to login page
            return redirect()->to('login')->with('info', 'Please login to continue with your order.');
        }
        
        // Check if user has insufficient funds (you'll need to implement this logic)
        $user = session()->get('user');
        $hasInsufficientFunds = true; // Set this based on your business logic
        
        // If logged in and has insufficient funds, redirect directly to select-payment
        if ($hasInsufficientFunds) {
            return redirect()->to('select-payment?plan=' . $plan);
        }
        
        // Otherwise, redirect to submit order page (this path won't be used after we delete the page)
        return redirect()->to('submit-order?plan=' . $plan);
    }

    public function panels()
    {
        return view('panels');
    }

    public function childPanels()
    {
        return view('child-panels');
    }

    public function addFund()
    {
        return view('add-fund');
    }

    public function help()
    {
        return view('help');
    }

    public function reviews()
    {
        return view('reviews');
    }

    public function account()
    {
        return view('account');
    }

    public function affiliate()
    {
        return view('affiliate');
    }
}
