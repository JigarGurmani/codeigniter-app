<?php

namespace App\Controllers;

use App\Models\OrderModel;
use App\Models\UserModel;

class Order extends BaseController
{
    public function index()
    {
        // Simple fallback for direct access
        return redirect()->to('/')->with('error', 'Please start from home page');
    }
    
    public function submitOrder()
    {
        // Get plan details from URL parameters
        $plan = $this->request->getGet('plan');
        $price = $this->request->getGet('price');
        
        // Define plan details
        $planDetails = [
            'A' => [
                'name' => 'Plan - A',
                'subtitle' => 'Starter Panel',
                'price' => 10,
                'features' => [
                    '5000 Orders Limit',
                    'Unlimited API',
                    'Weekly Backup',
                    'Premium Hosting',
                    'Basic Theme',
                    '24/7 Support',
                    'Weekly Updates',
                    'Best 4 Resellers'
                ]
            ],
            'B' => [
                'name' => 'Plan - B',
                'subtitle' => 'Premium Plan',
                'price' => 20,
                'features' => [
                    '20000 Orders Limit',
                    'Unlimited API',
                    'Premium Hosting',
                    '10+ Themes',
                    'SSL Protection',
                    '24/7 Support',
                    'Weekly Backup',
                    'Best 4 Bigginer'
                ]
            ],
            'C' => [
                'name' => 'Plan - C',
                'subtitle' => 'Business Plan',
                'price' => 35,
                'features' => [
                    '50000 Orders Limit',
                    'Website SEO',
                    'Secured VPS',
                    '20+ Themes',
                    'Unlimited API',
                    '24×7 Support',
                    'Daily Backup',
                    'Unlimited Bandwidth'
                ]
            ],
            'D' => [
                'name' => 'Plan - D',
                'subtitle' => 'Economy Plan',
                'price' => 60,
                'features' => [
                    'Unlimited Orders',
                    'Website SEO',
                    'Secured VPS',
                    '25+ Themes',
                    'Unlimited API',
                    '24×7 Support',
                    'Daily Backup',
                    'Free Domain (online)'
                ]
            ]
        ];
        
        // Validate plan
        if (!$plan || !isset($planDetails[$plan])) {
            return redirect()->to('/')->with('error', 'Invalid plan selected');
        }
        
        $data = [
            'selectedPlan' => $plan,
            'planInfo' => $planDetails[$plan],
            'title' => 'Submit Order - ' . $planDetails[$plan]['name']
        ];
        
        return view('submit_order', $data);
    }
    
    public function selectPayment()
    {
        // Accept both GET and POST for now
        $method = $this->request->getMethod();
        $isPost = ($method === 'post');
        
        // Get form data from either POST or GET
        if ($isPost) {
            $formData = $this->request->getPost();
            $planCode = $this->request->getPost('plan');
        } else {
            // For GET requests, get the plan from the URL
            $planCode = $this->request->getGet('plan');
            
            if (!$planCode) {
                return redirect()->to('/')->with('error', 'Invalid request. Please start from the homepage.');
            }
            
            // Create formData with minimal required information
            $formData = [
                'plan' => $planCode,
                'full_name' => session()->get('user')['full_name'] ?? '',
                'email' => session()->get('user')['email'] ?? '',
                'phone' => session()->get('user')['phone'] ?? '',
                'company_name' => session()->get('user')['company_name'] ?? '',
                'username' => session()->get('user')['username'] ?? 'temp_user_' . time(),
                'password' => session()->get('user')['password'] ?? 'TempPassword' . time(),
                'password_confirm' => session()->get('user')['password'] ?? 'TempPassword' . time(),
            ];
        }
        
        // Get plan details
        $planDetails = $this->getPlanDetails($planCode);
        
        // Prepare data for payment selection page
        $data = [
            'formData' => $formData,
            'orderId' => 'TEMP' . random_int(10000, 99999), // Temporary ID until order is saved
            'plan' => $planDetails['name'],
            'planCode' => $planCode,
            'price' => $planDetails['price'],
            'fullName' => $formData['full_name'],
            'email' => $formData['email'],
            'phone' => $formData['phone'],
            'title' => 'Select Payment Method'
        ];
        
        return view('select_payment', $data);
    }
    
    public function processOrder()
    {
        // Check if this is a direct access without form submission
        if ($this->request->getMethod() === 'get' || empty($this->request->getPost())) {
            // Sample data for demonstration when accessed directly
            $planDetails = $this->getPlanDetails('A');
            
            $demoData = [
                'orderId' => 'DEMO' . random_int(10000, 99999),
                'plan' => $planDetails['name'],
                'planCode' => 'A',
                'price' => $planDetails['price'],
                'fullName' => 'Demo User',
                'email' => 'demo@example.com',
                'phone' => '555-123-4567',
                'paymentMethod' => 'paypal',
                'title' => 'Process Payment - Demo Mode'
            ];
            
            return view('process_order', $demoData);
        }
        
        // Process POST form submission
        // Form validation rules - assuming it now comes from the payment selection page
        // processOrder function mein validation rules update karein
        $rules = [
            'full_name' => 'required|min_length[3]|max_length[100]',
            'email' => 'required|valid_email|max_length[100]',
            'phone' => 'required|min_length[5]|max_length[15]',
            'company_name' => 'permit_empty|max_length[100]',
            'plan' => 'required|in_list[A,B,C,D]',
            'payment_method' => 'required|in_list[paypal,stripe,bank_transfer,account_balance]'
        ];
        
        // Agar user logged in nahi hai to username/password validation add karein
        if (!session()->get('user')) {
            $rules['username'] = 'required|min_length[5]|max_length[50]';
            $rules['password'] = 'required|min_length[8]';
        }
        
        // We've already validated terms and password_confirm in the selectPayment method
        
        if (!$this->validate($rules)) {
            return redirect()->to('submit-order')->withInput()->with('errors', $this->validator->getErrors());
        }
        
        // Save order to database
        $orderModel = new OrderModel();
        $orderData = [
            'full_name' => $this->request->getPost('full_name'),
            'email' => $this->request->getPost('email'),
            'phone' => $this->request->getPost('phone'),
            'company_name' => $this->request->getPost('company_name'),
            'plan' => $this->request->getPost('plan'),
            'payment_method' => $this->request->getPost('payment_method'),
            'status' => 'pending',
            'order_date' => date('Y-m-d H:i:s')
        ];
        
        if ($orderModel->insert($orderData)) {
            $orderId = $orderModel->getInsertID();
            
            // Get plan details
            $planDetails = $this->getPlanDetails($this->request->getPost('plan'));
            
            // Prepare data for payment page
            $paymentData = [
                'orderId' => $orderId,
                'plan' => $planDetails['name'],
                'planCode' => $this->request->getPost('plan'),
                'price' => $planDetails['price'],
                'fullName' => $this->request->getPost('full_name'),
                'email' => $this->request->getPost('email'),
                'phone' => $this->request->getPost('phone'),
                'paymentMethod' => $this->request->getPost('payment_method'),
                'title' => 'Process Payment'
            ];
            
            // Save user data to session for registration after payment
            $userSession = [
                'username' => $this->request->getPost('username'),
                'password' => $this->request->getPost('password'), 
                'full_name' => $this->request->getPost('full_name'),
                'email' => $this->request->getPost('email'),
                'phone' => $this->request->getPost('phone'),
                'company_name' => $this->request->getPost('company_name'),
                'plan' => $this->request->getPost('plan'),
                'order_id' => $orderId
            ];
            
            session()->set('pending_user', $userSession);
            
            // Redirect to payment processing page
            return view('process_order', $paymentData);
        } else {
            return redirect()->back()->withInput()->with('error', 'Failed to submit order. Please try again.');
        }
    }
    
    public function processPayPal()
    {
        // In a real system, this would interact with the PayPal API
        // For now, we'll simulate a successful payment
        
        // Get order ID from the form
        $orderId = $this->request->getPost('order_id');
        
        // Update order status
        if ($orderId) {
            $orderModel = new OrderModel();
            $orderModel->update($orderId, ['status' => 'paid', 'payment_date' => date('Y-m-d H:i:s')]);
        }
        
        return $this->completePayment();
    }
    
    public function processStripe()
    {
        // In a real system, this would interact with the Stripe API
        // For now, we'll simulate a successful payment
        
        // Get order ID from the form
        $orderId = $this->request->getPost('order_id');
        
        // Update order status
        if ($orderId) {
            $orderModel = new OrderModel();
            $orderModel->update($orderId, ['status' => 'paid', 'payment_date' => date('Y-m-d H:i:s')]);
        }
        
        return $this->completePayment();
    }
    
    public function processAccountBalance()
    {
        // Get order ID and plan from the form
        $orderId = $this->request->getPost('order_id');
        $planCode = $this->request->getPost('plan');
        
        // Get user from session
        $userSession = session()->get('user');
        
        if (!$userSession || !isset($userSession['id'])) {
            return redirect()->to('/')->with('error', 'User session expired. Please login again.');
        }
        
        $userId = $userSession['id'];
        $userModel = new UserModel();
        $user = $userModel->find($userId);
        
        if (!$user) {
            return redirect()->to('/')->with('error', 'User not found.');
        }
        
        // Get plan details and price
        $planDetails = $this->getPlanDetails($planCode);
        $planPrice = $planDetails['price'];
        
        // Check if user has sufficient balance
        $userBalance = $user['balance'] ?? 0;
        
        if ($userBalance < $planPrice) {
            return redirect()->to('select-payment?plan=' . $planCode)
                            ->with('error', 'Insufficient funds in your account balance. Please select another payment method.');
        }
        
        // Process payment from account balance
        $newBalance = $userBalance - $planPrice;
        
        // Update user balance
        $userModel->update($userId, ['balance' => $newBalance]);
        
        // Update order status
        if ($orderId) {
            $orderModel = new OrderModel();
            $orderModel->update($orderId, [
                'status' => 'paid', 
                'payment_date' => date('Y-m-d H:i:s'),
                'payment_method' => 'account_balance'
            ]);
        }
        
        // Update session with new balance
        $userData = session()->get('user');
        $userData['balance'] = $newBalance;
        session()->set('user', $userData);
        
        return $this->completePayment();
    }
    
    // This would be called by payment gateway callbacks or manually by user after bank transfer
    public function completePayment()
    {
        // Get the pending user data from session
        $pendingUser = session()->get('pending_user');
        
        if (!$pendingUser) {
            return redirect()->to('/')->with('error', 'No pending registration found');
        }
        
        // Register the user
        $userModel = new UserModel();
        $userData = [
            'username' => $pendingUser['username'],
            'password' => password_hash($pendingUser['password'], PASSWORD_DEFAULT),
            'full_name' => $pendingUser['full_name'],
            'email' => $pendingUser['email'],
            'phone' => $pendingUser['phone'],
            'company_name' => $pendingUser['company_name'],
            'plan' => $pendingUser['plan'],
            'status' => 'active',
            'registration_date' => date('Y-m-d H:i:s')
        ];
        
        if ($userModel->insert($userData)) {
            // Update order status
            $orderModel = new OrderModel();
            $orderModel->update($pendingUser['order_id'], ['status' => 'confirmed']);
            
            // Clear session data
            session()->remove('pending_user');
            
            return redirect()->to('order-confirmation/' . $pendingUser['order_id'])
                            ->with('success', 'Payment received and account created successfully!');
        } else {
            return redirect()->to('submit-order')
                            ->with('error', 'Failed to create account. Please contact support.');
        }
    }
    
    public function confirmation($orderId)
    {
        $orderModel = new OrderModel();
        $order = $orderModel->find($orderId);
        
        if (!$order) {
            return redirect()->to('/')->with('error', 'Order not found');
        }
        
        $data = [
            'order' => $order,
            'title' => 'Order Confirmation'
        ];
        
        return view('order_confirmation', $data);
    }
    
    private function getPlanDetails($planCode)
    {
        $planDetails = [
            'A' => [
                'name' => 'Plan - A',
                'subtitle' => 'Starter Panel',
                'price' => 10,
                'features' => [
                    '5000 Orders Limit',
                    'Unlimited API',
                    'Weekly Backup',
                    'Premium Hosting',
                    'Basic Theme',
                    '24/7 Support',
                    'Weekly Updates',
                    'Best 4 Resellers'
                ]
            ],
            'B' => [
                'name' => 'Plan - B',
                'subtitle' => 'Premium Plan',
                'price' => 20,
                'features' => [
                    '20000 Orders Limit',
                    'Unlimited API',
                    'Premium Hosting',
                    '10+ Themes',
                    'SSL Protection',
                    '24/7 Support',
                    'Weekly Backup',
                    'Best 4 Bigginer'
                ]
            ],
            'C' => [
                'name' => 'Plan - C',
                'subtitle' => 'Business Plan',
                'price' => 35,
                'features' => [
                    '50000 Orders Limit',
                    'Website SEO',
                    'Secured VPS',
                    '20+ Themes',
                    'Unlimited API',
                    '24×7 Support',
                    'Daily Backup',
                    'Unlimited Bandwidth'
                ]
            ],
            'D' => [
                'name' => 'Plan - D',
                'subtitle' => 'Economy Plan',
                'price' => 60,
                'features' => [
                    'Unlimited Orders',
                    'Website SEO',
                    'Secured VPS',
                    '25+ Themes',
                    'Unlimited API',
                    '24×7 Support',
                    'Daily Backup',
                    'Free Domain (online)'
                ]
            ]
        ];
        
        return $planDetails[$planCode] ?? $planDetails['A'];
    }
    
    public function login()
    {
        return view('login');
    }
    
    public function authenticate()
    {
        // Validate user credentials
        $rules = [
            'username' => 'required|min_length[3]',
            'password' => 'required|min_length[8]'
        ];
        
        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
        // Get user credentials
        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');
        
        // Check if user exists
        $userModel = new UserModel();
        $user = $userModel->where('username', $username)->first();
        
        // If user doesn't exist or password doesn't match
        if (!$user) {
            return redirect()->back()->withInput()->with('error', 'Invalid username or password');
        }
        
        // Verify password
        $passwordVerify = password_verify($password, $user['password']);
        if (!$passwordVerify) {
            return redirect()->back()->withInput()->with('error', 'Invalid username or password');
        }
        
        // Set user session
        $userData = [
            'id' => $user['id'],
            'username' => $user['username'],
            'full_name' => $user['full_name'],
            'email' => $user['email'],
            'isLoggedIn' => true
        ];
        
        session()->set('user', $userData);
        
        // Update last login time
        $userModel->update($user['id'], ['last_login' => date('Y-m-d H:i:s')]);
        
        // Redirect to dashboard
        return redirect()->to('dashboard');
    }
    
    public function register()
    {
        return view('register');
    }
    
    public function createAccount()
    {
        // Validation rules for registration
        $rules = [
            'username' => 'required|min_length[3]|is_unique[users.username]',
            'password' => 'required|min_length[8]',
            'password_confirm' => 'required|matches[password]',
            'full_name' => 'required',
            'email' => 'required|valid_email|is_unique[users.email]',
            'phone' => 'required|min_length[5]|max_length[15]'
        ];
        
        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        
        // Insert user data
        $userModel = new UserModel();
        $userData = [
            'username' => $this->request->getPost('username'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
            'full_name' => $this->request->getPost('full_name'),
            'email' => $this->request->getPost('email'),
            'phone' => $this->request->getPost('phone'),
            'company_name' => $this->request->getPost('company_name'),
            'status' => 'active',
            'registration_date' => date('Y-m-d H:i:s')
        ];
        
        if ($userModel->insert($userData)) {
            // Set success message and redirect to login
            return redirect()->to('login')->with('success', 'Account created successfully! Please login.');
        } else {
            // Set error message and redirect back to registration form
            return redirect()->back()->withInput()->with('error', 'Failed to create account. Please try again.');
        }
    }
    
    public function dashboard()
    {
        // Check if user is logged in
        if (!session()->get('user')) {
            return redirect()->to('login')->with('error', 'Please login to access the dashboard');
        }
        
        // Get user data
        $userData = session()->get('user');
        
        // Get user's orders
        $orderModel = new OrderModel();
        $orders = $orderModel->where('user_id', $userData['id'])->findAll();
        
        $data = [
            'title' => 'User Dashboard',
            'user' => $userData,
            'orders' => $orders
        ];
        
        return view('dashboard', $data);
    }
    
    public function logout()
    {
        // Destroy user session
        session()->destroy();
        
        // Redirect to home page
        return redirect()->to('/')->with('success', 'Logged out successfully');
    }
}