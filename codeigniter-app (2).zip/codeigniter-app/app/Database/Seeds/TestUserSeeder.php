<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class TestUserSeeder extends Seeder
{
    public function run()
    {
        $data = [
            'username'         => 'demo',
            'password'         => password_hash('demo12345', PASSWORD_DEFAULT),
            'full_name'        => 'Demo User',
            'email'            => 'demo@example.com',
            'phone'            => '123-456-7890',
            'company_name'     => 'Demo Company',
            'plan'             => 'A',
            'status'           => 'active',
            'registration_date' => date('Y-m-d H:i:s'),
            'created_at'       => date('Y-m-d H:i:s'),
            'updated_at'       => date('Y-m-d H:i:s')
        ];

        // Insert the data
        $this->db->table('users')->insert($data);

        echo "Demo user created with credentials: demo / demo12345\n";
    }
} 