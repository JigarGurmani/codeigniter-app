<?php

namespace App\Models;

use CodeIgniter\Model;

class OrderModel extends Model
{
    protected $table = 'orders';
    protected $primaryKey = 'id';
    
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    
    protected $allowedFields = [
        'full_name', 'email', 'phone', 'company_name', 
        'plan', 'payment_method', 'status', 'order_date',
        'user_id', 'total_amount', 'payment_date'
    ];
    
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';
    
    protected $validationRules = [
        'full_name' => 'required|min_length[3]|max_length[100]',
        'email' => 'required|valid_email|max_length[100]',
        'phone' => 'required|min_length[10]|max_length[15]',
        'plan' => 'required|in_list[A,B,C,D]',
        'payment_method' => 'required|in_list[paypal,stripe,bank_transfer]'
    ];
}