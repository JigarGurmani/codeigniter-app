<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table = 'users';
    protected $primaryKey = 'id';
    
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    
    protected $allowedFields = [
        'username', 'password', 'full_name', 'email', 'phone', 
        'company_name', 'plan', 'status', 'registration_date', 'last_login', 'balance'
    ];
    
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';
    
    protected $validationRules = [
        'username' => 'required|min_length[5]|max_length[50]|is_unique[users.username,id,{id}]',
        'email' => 'required|valid_email|max_length[100]|is_unique[users.email,id,{id}]',
        'full_name' => 'required|min_length[3]|max_length[100]',
        'phone' => 'required|min_length[5]|max_length[15]'
    ];
    
    /**
     * Hash passwords before storing
     */
    protected function hashPassword(array $data)
    {
        if (isset($data['data']['password'])) {
            $data['data']['password'] = password_hash($data['data']['password'], PASSWORD_DEFAULT);
        }

        return $data;
    }
    
    protected function beforeInsert(array $data)
    {
        return $this->hashPassword($data);
    }
    
    protected function beforeUpdate(array $data)
    {
        return $this->hashPassword($data);
    }
    
    // Add this method to the UserModel class
    public function hasInsufficientFunds($userId, $planPrice)
    {
        $user = $this->find($userId);
        
        // Assuming you have a balance field in your users table
        // If not, you'll need to modify this logic based on your business requirements
        $balance = $user['balance'] ?? 0;
        
        return $balance < $planPrice;
    }
}
