<?php
$page_title = "Account";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account - Geo Rental Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary: #6f42c1;
            --primary-light: #8458e2;
            --primary-dark: #5e35b1;
            --secondary: #6c757d;
            --topbar-height: 60px;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f7ff;
            color: #333;
            padding-top: 70px;
        }
        .container-fluid {
            padding: 0;
        }

        /* Main Content */
        .main-content {
            background-color: #f5f7ff;
            min-height: 100vh;
            padding: 25px;
        }

        /* Card Styles */
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.05);
            margin-bottom: 25px;
        }
        
        .card-body {
            padding: 20px;
        }
        
        .account-section {
            border-bottom: 1px solid #eee;
            padding-bottom: 20px;
            margin-bottom: 20px;
        }
        
        .account-section:last-child {
            border-bottom: none;
            padding-bottom: 0;
            margin-bottom: 0;
        }
        
        .profile-avatar {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            background-color: var(--primary);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 40px;
            font-weight: 600;
            margin: 0 auto 20px;
            position: relative;
        }
        
        .profile-avatar-edit {
            position: absolute;
            bottom: 0;
            right: 0;
            background-color: white;
            width: 36px;
            height: 36px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
            cursor: pointer;
            color: var(--primary);
            transition: all 0.3s ease;
        }
        
        .profile-avatar-edit:hover {
            background-color: var(--primary);
            color: white;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            font-weight: 500;
            margin-bottom: 8px;
            color: #333;
        }
        
        .form-control {
            border-radius: 8px;
            padding: 10px 15px;
            border: 1px solid #e1e5eb;
        }
        
        .form-control:focus {
            box-shadow: 0 0 0 3px rgba(111, 66, 193, 0.25);
            border-color: var(--primary);
        }
        
        .form-text {
            font-size: 12px;
            color: #6c757d;
        }
        
        .form-check {
            margin-bottom: 10px;
        }
        
        .security-card {
            background-color: #fff;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 15px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .security-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: rgba(111, 66, 193, 0.1);
            color: var(--primary);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
            margin-right: 15px;
        }
        
        .security-info {
            flex-grow: 1;
        }
        
        .security-info h6 {
            margin-bottom: 3px;
            font-weight: 600;
            color: #333;
        }
        
        .security-info p {
            margin-bottom: 0;
            font-size: 13px;
            color: #6c757d;
        }
        
        .security-status {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .security-status.enabled {
            background-color: rgba(40, 167, 69, 0.1);
            color: #28a745;
        }
        
        .security-status.disabled {
            background-color: rgba(220, 53, 69, 0.1);
            color: #dc3545;
        }
        
        .activity-log {
            margin-top: 20px;
        }
        
        .activity-item {
            padding: 12px 0;
            border-bottom: 1px solid #eee;
            display: flex;
            align-items: flex-start;
        }
        
        .activity-item:last-child {
            border-bottom: none;
        }
        
        .activity-icon {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background-color: rgba(111, 66, 193, 0.1);
            color: var(--primary);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
            margin-right: 12px;
            flex-shrink: 0;
        }
        
        .activity-info {
            flex-grow: 1;
        }
        
        .activity-text {
            margin-bottom: 3px;
            font-size: 14px;
            color: #333;
        }
        
        .activity-time {
            font-size: 12px;
            color: #6c757d;
        }
        
        .btn-primary {
            background-color: var(--primary);
            border-color: var(--primary);
        }
        
        .btn-primary:hover {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
        }
        
        .nav-tabs {
            border-bottom: none;
            margin-bottom: 20px;
        }
        
        .nav-tabs .nav-link {
            border: none;
            border-radius: 8px;
            padding: 10px 15px;
            margin-right: 10px;
            color: #495057;
            transition: all 0.3s ease;
        }
        
        .nav-tabs .nav-link:hover {
            background-color: rgba(111, 66, 193, 0.05);
            color: var(--primary);
        }
        
        .nav-tabs .nav-link.active {
            background-color: var(--primary);
            color: white;
        }
        
        .page-title {
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #dee2e6;
            font-weight: 600;
            color: #333;
        }
        
        /* Responsive Adjustments */
        @media (max-width: 768px) {
            body {
                padding-top: 80px;
            }
            
            .main-content {
                padding-top: 15px;
            }
        }
    </style>
</head>
<body>
<?= $this->include('templates/navbardashboard') ?>
    
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 main-content">
                <?php if(session()->getFlashdata('success')): ?>
                    <div class="alert alert-success">
                        <?= session()->getFlashdata('success') ?>
                    </div>
                <?php endif; ?>
                
                <?php if(session()->getFlashdata('error')): ?>
                    <div class="alert alert-danger">
                        <?= session()->getFlashdata('error') ?>
                    </div>
                <?php endif; ?>
                
                <!-- Account Content -->
                <h1 class="page-title">Account Settings</h1>
                
                <!-- Account Settings Tabs -->
                <ul class="nav nav-tabs" id="accountTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <a class="nav-link active" id="profile-tab" data-bs-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="true">
                            <i class="fas fa-user me-2"></i> Profile
                        </a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a class="nav-link" id="security-tab" data-bs-toggle="tab" href="#security" role="tab" aria-controls="security" aria-selected="false">
                            <i class="fas fa-shield-alt me-2"></i> Security
                        </a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a class="nav-link" id="notifications-tab" data-bs-toggle="tab" href="#notifications" role="tab" aria-controls="notifications" aria-selected="false">
                            <i class="fas fa-bell me-2"></i> Notifications
                        </a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a class="nav-link" id="billing-tab" data-bs-toggle="tab" href="#billing" role="tab" aria-controls="billing" aria-selected="false">
                            <i class="fas fa-credit-card me-2"></i> Billing
                        </a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a class="nav-link" id="activity-tab" data-bs-toggle="tab" href="#activity" role="tab" aria-controls="activity" aria-selected="false">
                            <i class="fas fa-history me-2"></i> Activity
                        </a>
                    </li>
                </ul>
                
                <!-- Tab Content -->
                <div class="tab-content" id="accountTabsContent">
                    <!-- Profile Tab -->
                    <div class="tab-pane fade show active" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                        <div class="row">
                            <div class="col-lg-4 mb-4">
                                <div class="card">
                                    <div class="card-body text-center">
                                        <div class="profile-avatar">
                                            JD
                                            <div class="profile-avatar-edit">
                                                <i class="fas fa-camera"></i>
                                            </div>
                                        </div>
                                        <h5 class="mb-1">John Doe</h5>
                                        <p class="text-muted mb-3">johndoe@example.com</p>
                                        <p><span class="badge bg-success">Premium Member</span></p>
                                        <div class="d-grid gap-2">
                                            <button class="btn btn-primary">
                                                <i class="fas fa-image me-2"></i> Change Profile Picture
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-lg-8">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title mb-4">Personal Information</h5>
                                        
                                        <form>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="firstName" class="form-label">First Name</label>
                                                        <input type="text" class="form-control" id="firstName" value="John">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="lastName" class="form-label">Last Name</label>
                                                        <input type="text" class="form-control" id="lastName" value="Doe">
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div class="form-group">
                                                <label for="email" class="form-label">Email Address</label>
                                                <input type="email" class="form-control" id="email" value="johndoe@example.com">
                                                <div class="form-text">Your email address is verified.</div>
                                            </div>
                                            
                                            <div class="form-group">
                                                <label for="phone" class="form-label">Phone Number</label>
                                                <input type="tel" class="form-control" id="phone" value="+1 123-456-7890">
                                            </div>
                                            
                                            <div class="form-group">
                                                <label for="company" class="form-label">Company</label>
                                                <input type="text" class="form-control" id="company" value="Acme Inc.">
                                            </div>
                                            
                                            <div class="form-group">
                                                <label for="website" class="form-label">Website</label>
                                                <input type="url" class="form-control" id="website" value="https://example.com">
                                            </div>
                                            
                                            <div class="form-group">
                                                <label for="bio" class="form-label">Bio</label>
                                                <textarea class="form-control" id="bio" rows="4">Social media marketing expert with over 5 years of experience in growing online presence for small businesses.</textarea>
                                            </div>
                                            
                                            <button type="submit" class="btn btn-primary">Save Changes</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Security Tab -->
                    <div class="tab-pane fade" id="security" role="tabpanel" aria-labelledby="security-tab">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title mb-4">Security Settings</h5>
                                
                                <div class="account-section">
                                    <h6 class="mb-3">Change Password</h6>
                                    <form>
                                        <div class="form-group">
                                            <label for="currentPassword" class="form-label">Current Password</label>
                                            <input type="password" class="form-control" id="currentPassword">
                                        </div>
                                        
                                        <div class="form-group">
                                            <label for="newPassword" class="form-label">New Password</label>
                                            <input type="password" class="form-control" id="newPassword">
                                        </div>
                                        
                                        <div class="form-group">
                                            <label for="confirmPassword" class="form-label">Confirm New Password</label>
                                            <input type="password" class="form-control" id="confirmPassword">
                                        </div>
                                        
                                        <button type="submit" class="btn btn-primary">Update Password</button>
                                    </form>
                                </div>
                                
                                <div class="account-section">
                                    <h6 class="mb-3">Two-Factor Authentication</h6>
                                    <div class="security-card">
                                        <div class="d-flex align-items-center">
                                            <div class="security-icon">
                                                <i class="fas fa-mobile-alt"></i>
                                            </div>
                                            <div class="security-info">
                                                <h6>Text Message Authentication</h6>
                                                <p>Receive a verification code via SMS</p>
                                            </div>
                                        </div>
                                        <span class="security-status enabled">Enabled</span>
                                    </div>
                                    
                                    <div class="security-card">
                                        <div class="d-flex align-items-center">
                                            <div class="security-icon">
                                                <i class="fas fa-key"></i>
                                            </div>
                                            <div class="security-info">
                                                <h6>Authenticator App</h6>
                                                <p>Use Google Authenticator or similar apps</p>
                                            </div>
                                        </div>
                                        <span class="security-status disabled">Disabled</span>
                                    </div>
                                    
                                    <div class="security-card">
                                        <div class="d-flex align-items-center">
                                            <div class="security-icon">
                                                <i class="fas fa-shield-alt"></i>
                                            </div>
                                            <div class="security-info">
                                                <h6>Security Questions</h6>
                                                <p>Answer personal questions to verify identity</p>
                                            </div>
                                        </div>
                                        <span class="security-status enabled">Enabled</span>
                                    </div>
                                </div>
                                
                                <div class="account-section">
                                    <h6 class="mb-3">Login Sessions</h6>
                                    <p class="text-muted">These are devices that have logged into your account. Revoke any sessions that you do not recognize.</p>
                                    
                                    <div class="security-card">
                                        <div class="d-flex align-items-center">
                                            <div class="security-icon">
                                                <i class="fas fa-laptop"></i>
                                            </div>
                                            <div class="security-info">
                                                <h6>Windows PC - Chrome</h6>
                                                <p>Last active: 2 minutes ago - New York, USA</p>
                                            </div>
                                        </div>
                                        <span class="badge bg-success">Current</span>
                                    </div>
                                    
                                    <div class="security-card">
                                        <div class="d-flex align-items-center">
                                            <div class="security-icon">
                                                <i class="fas fa-mobile-alt"></i>
                                            </div>
                                            <div class="security-info">
                                                <h6>iPhone 13 - Safari</h6>
                                                <p>Last active: Yesterday - New York, USA</p>
                                            </div>
                                        </div>
                                        <button class="btn btn-sm btn-outline-danger">Revoke</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Notifications Tab -->
                    <div class="tab-pane fade" id="notifications" role="tabpanel" aria-labelledby="notifications-tab">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title mb-4">Notification Preferences</h5>
                                
                                <div class="account-section">
                                    <h6 class="mb-3">Email Notifications</h6>
                                    
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="" id="orderUpdates" checked>
                                        <label class="form-check-label" for="orderUpdates">
                                            Order Updates
                                            <div class="form-text">Receive updates about your orders and services.</div>
                                        </label>
                                    </div>
                                    
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="" id="accountActivity" checked>
                                        <label class="form-check-label" for="accountActivity">
                                            Account Activity
                                            <div class="form-text">Receive notifications about your account security and activity.</div>
                                        </label>
                                    </div>
                                    
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="" id="promotions">
                                        <label class="form-check-label" for="promotions">
                                            Promotions and Offers
                                            <div class="form-text">Receive updates about special offers and discounts.</div>
                                        </label>
                                    </div>
                                    
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="" id="newsletter" checked>
                                        <label class="form-check-label" for="newsletter">
                                            Newsletter
                                            <div class="form-text">Receive our monthly newsletter with industry insights and tips.</div>
                                        </label>
                                    </div>
                                </div>
                                
                                <div class="account-section">
                                    <h6 class="mb-3">Push Notifications</h6>
                                    
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="" id="pushOrderUpdates" checked>
                                        <label class="form-check-label" for="pushOrderUpdates">
                                            Order Updates
                                            <div class="form-text">Receive push notifications about your orders and services.</div>
                                        </label>
                                    </div>
                                    
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="" id="pushAccountActivity" checked>
                                        <label class="form-check-label" for="pushAccountActivity">
                                            Account Activity
                                            <div class="form-text">Receive push notifications about your account security and activity.</div>
                                        </label>
                                    </div>
                                    
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="" id="pushPromotions">
                                        <label class="form-check-label" for="pushPromotions">
                                            Promotions and Offers
                                            <div class="form-text">Receive push notifications about special offers and discounts.</div>
                                        </label>
                                    </div>
                                </div>
                                
                                <button type="submit" class="btn btn-primary">Save Preferences</button>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Billing Tab -->
                    <div class="tab-pane fade" id="billing" role="tabpanel" aria-labelledby="billing-tab">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title mb-4">Billing Information</h5>
                                
                                <div class="account-section">
                                    <h6 class="mb-3">Payment Methods</h6>
                                    
                                    <div class="security-card">
                                        <div class="d-flex align-items-center">
                                            <div class="security-icon">
                                                <i class="fab fa-cc-visa"></i>
                                            </div>
                                            <div class="security-info">
                                                <h6>Visa ending in 4242</h6>
                                                <p>Expires 04/2025</p>
                                            </div>
                                        </div>
                                        <div>
                                            <span class="badge bg-success me-2">Default</span>
                                            <button class="btn btn-sm btn-outline-secondary">Edit</button>
                                        </div>
                                    </div>
                                    
                                    <div class="security-card">
                                        <div class="d-flex align-items-center">
                                            <div class="security-icon">
                                                <i class="fab fa-paypal"></i>
                                            </div>
                                            <div class="security-info">
                                                <h6>PayPal</h6>
                                                <p>johndoe@example.com</p>
                                            </div>
                                        </div>
                                        <div>
                                            <button class="btn btn-sm btn-outline-secondary me-2">Set as Default</button>
                                            <button class="btn btn-sm btn-outline-secondary">Edit</button>
                                        </div>
                                    </div>
                                    
                                    <button class="btn btn-outline-primary mt-3">
                                        <i class="fas fa-plus me-2"></i> Add Payment Method
                                    </button>
                                </div>
                                
                                <div class="account-section">
                                    <h6 class="mb-3">Billing Address</h6>
                                    
                                    <form>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="billingName" class="form-label">Full Name</label>
                                                    <input type="text" class="form-control" id="billingName" value="John Doe">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="billingCompany" class="form-label">Company (Optional)</label>
                                                    <input type="text" class="form-control" id="billingCompany" value="Acme Inc.">
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label for="billingAddress" class="form-label">Address</label>
                                            <input type="text" class="form-control" id="billingAddress" value="123 Main St">
                                        </div>
                                        
                                        <div class="form-group">
                                            <label for="billingAddress2" class="form-label">Address Line 2 (Optional)</label>
                                            <input type="text" class="form-control" id="billingAddress2" value="Suite 456">
                                        </div>
                                        
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="billingCity" class="form-label">City</label>
                                                    <input type="text" class="form-control" id="billingCity" value="New York">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="billingState" class="form-label">State</label>
                                                    <input type="text" class="form-control" id="billingState" value="NY">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="billingZip" class="form-label">ZIP Code</label>
                                                    <input type="text" class="form-control" id="billingZip" value="10001">
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label for="billingCountry" class="form-label">Country</label>
                                            <select class="form-select" id="billingCountry">
                                                <option value="US" selected>United States</option>
                                                <option value="CA">Canada</option>
                                                <option value="UK">United Kingdom</option>
                                                <option value="AU">Australia</option>
                                            </select>
                                        </div>
                                        
                                        <button type="submit" class="btn btn-primary mt-3">Save Address</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Activity Tab -->
                    <div class="tab-pane fade" id="activity" role="tabpanel" aria-labelledby="activity-tab">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title mb-4">Account Activity</h5>
                                
                                <div class="activity-log">
                                    <div class="activity-item">
                                        <div class="activity-icon">
                                            <i class="fas fa-sign-in-alt"></i>
                                        </div>
                                        <div class="activity-info">
                                            <div class="activity-text">Logged in from Chrome on Windows</div>
                                            <div class="activity-time">Today, 10:30 AM - IP: 192.168.1.1</div>
                                        </div>
                                    </div>
                                    
                                    <div class="activity-item">
                                        <div class="activity-icon">
                                            <i class="fas fa-credit-card"></i>
                                        </div>
                                        <div class="activity-info">
                                            <div class="activity-text">Added funds to your account ($100)</div>
                                            <div class="activity-time">Yesterday, 2:45 PM - IP: 192.168.1.1</div>
                                        </div>
                                    </div>
                                    
                                    <div class="activity-item">
                                        <div class="activity-icon">
                                            <i class="fas fa-cog"></i>
                                        </div>
                                        <div class="activity-info">
                                            <div class="activity-text">Changed account password</div>
                                            <div class="activity-time">August 10, 2023, 11:15 AM - IP: 192.168.1.1</div>
                                        </div>
                                    </div>
                                    
                                    <div class="activity-item">
                                        <div class="activity-icon">
                                            <i class="fas fa-shopping-cart"></i>
                                        </div>
                                        <div class="activity-info">
                                            <div class="activity-text">Purchased Premium Plan subscription</div>
                                            <div class="activity-time">August 5, 2023, 3:20 PM - IP: 192.168.1.1</div>
                                        </div>
                                    </div>
                                    
                                    <div class="activity-item">
                                        <div class="activity-icon">
                                            <i class="fas fa-sign-in-alt"></i>
                                        </div>
                                        <div class="activity-info">
                                            <div class="activity-text">Logged in from Safari on iPhone</div>
                                            <div class="activity-time">August 2, 2023, 9:45 AM - IP: 192.168.1.2</div>
                                        </div>
                                    </div>
                                    
                                    <div class="activity-item">
                                        <div class="activity-icon">
                                            <i class="fas fa-user-edit"></i>
                                        </div>
                                        <div class="activity-info">
                                            <div class="activity-text">Updated profile information</div>
                                            <div class="activity-time">July 28, 2023, 4:10 PM - IP: 192.168.1.1</div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="text-center mt-4">
                                    <button class="btn btn-outline-primary">Load More Activity</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 