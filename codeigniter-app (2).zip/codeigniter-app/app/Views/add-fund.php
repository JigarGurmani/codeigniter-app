<?php
$page_title = "Add Fund";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Fund - Geo Rental Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary: #6f42c1;
            --primary-light: #8458e2;
            --primary-dark: #5e35b1;
            --secondary: #6c757d;
            --topbar-height: 60px;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f7ff;
            color: #333;
            padding-top: 70px;
        }
        .container-fluid {
            padding: 0;
        }

        /* Main Content */
        .main-content {
            background-color: #f5f7ff;
            min-height: 100vh;
            padding: 25px;
        }

        /* Card Styles */
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.05);
            margin-bottom: 25px;
        }
        
        .card-body {
            padding: 20px;
        }
        
        .payment-card {
            border: 2px solid rgba(0,0,0,0.05);
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
            transition: all 0.3s ease;
            cursor: pointer;
            display: flex;
            align-items: center;
        }
        
        .payment-card:hover {
            border-color: var(--primary);
            background-color: rgba(111, 66, 193, 0.03);
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(0,0,0,0.05);
        }
        
        .payment-card.selected {
            border-color: var(--primary);
            background-color: rgba(111, 66, 193, 0.05);
            box-shadow: 0 5px 15px rgba(111, 66, 193, 0.1);
        }
        
        .payment-icon {
            width: 50px;
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            margin-right: 20px;
            color: var(--primary);
        }
        
        .payment-info {
            flex-grow: 1;
        }
        
        .payment-info h5 {
            margin-bottom: 5px;
            font-weight: 600;
        }
        
        .payment-info p {
            margin-bottom: 0;
            color: #6c757d;
            font-size: 14px;
        }
        
        .fund-amount-btn {
            border: 2px solid rgba(0,0,0,0.05);
            border-radius: 8px;
            padding: 15px;
            text-align: center;
            font-weight: 600;
            font-size: 18px;
            margin-bottom: 15px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .fund-amount-btn:hover {
            border-color: var(--primary);
            background-color: rgba(111, 66, 193, 0.03);
            transform: translateY(-2px);
        }
        
        .fund-amount-btn.selected {
            border-color: var(--primary);
            background-color: rgba(111, 66, 193, 0.05);
            color: var(--primary);
        }
        
        .custom-amount {
            margin-top: 20px;
        }
        
        .transaction-card {
            border: none;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 10px;
            background-color: white;
            box-shadow: 0 2px 8px rgba(0,0,0,0.04);
            transition: all 0.3s ease;
        }
        
        .transaction-card:hover {
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            transform: translateY(-2px);
        }
        
        .transaction-status {
            display: inline-block;
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .transaction-status.completed {
            background-color: rgba(40, 167, 69, 0.1);
            color: #28a745;
        }
        
        .transaction-status.pending {
            background-color: rgba(255, 193, 7, 0.1);
            color: #ffc107;
        }
        
        .transaction-status.failed {
            background-color: rgba(220, 53, 69, 0.1);
            color: #dc3545;
        }
        
        .page-title {
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #dee2e6;
            font-weight: 600;
            color: #333;
        }
        
        /* Responsive Adjustments */
        @media (max-width: 768px) {
            body {
                padding-top: 80px;
            }
            
            .main-content {
                padding-top: 15px;
            }
        }
    </style>
</head>
<body>
<?= $this->include('templates/navbardashboard') ?>
    
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 main-content">
                <?php if(session()->getFlashdata('success')): ?>
                    <div class="alert alert-success">
                        <?= session()->getFlashdata('success') ?>
                    </div>
                <?php endif; ?>
                
                <?php if(session()->getFlashdata('error')): ?>
                    <div class="alert alert-danger">
                        <?= session()->getFlashdata('error') ?>
                    </div>
                <?php endif; ?>
                
                <!-- Add Fund Content -->
                <h1 class="page-title">Add Fund</h1>
                
                <div class="row">
                    <div class="col-lg-8">
                        <div class="card mb-4">
                            <div class="card-body">
                                <h5 class="card-title mb-4">Select Payment Method</h5>
                                
                                <!-- Payment Methods -->
                                <div class="payment-card selected">
                                    <div class="payment-icon">
                                        <i class="fab fa-paypal"></i>
                                    </div>
                                    <div class="payment-info">
                                        <h5>PayPal</h5>
                                        <p>Fast and secure online payment</p>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="paymentMethod" id="paypalMethod" checked>
                                        <label class="form-check-label" for="paypalMethod"></label>
                                    </div>
                                </div>
                                
                                <div class="payment-card">
                                    <div class="payment-icon">
                                        <i class="fas fa-credit-card"></i>
                                    </div>
                                    <div class="payment-info">
                                        <h5>Credit Card</h5>
                                        <p>Pay with Visa, Mastercard, or American Express</p>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="paymentMethod" id="cardMethod">
                                        <label class="form-check-label" for="cardMethod"></label>
                                    </div>
                                </div>
                                
                                <div class="payment-card">
                                    <div class="payment-icon">
                                        <i class="fas fa-university"></i>
                                    </div>
                                    <div class="payment-info">
                                        <h5>Bank Transfer</h5>
                                        <p>Direct bank deposit to our account</p>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="paymentMethod" id="bankMethod">
                                        <label class="form-check-label" for="bankMethod"></label>
                                    </div>
                                </div>
                                
                                <div class="payment-card">
                                    <div class="payment-icon">
                                        <i class="fab fa-bitcoin"></i>
                                    </div>
                                    <div class="payment-info">
                                        <h5>Cryptocurrency</h5>
                                        <p>Pay with Bitcoin, Ethereum, or other cryptocurrencies</p>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="paymentMethod" id="cryptoMethod">
                                        <label class="form-check-label" for="cryptoMethod"></label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title mb-4">Select Amount</h5>
                                
                                <div class="row">
                                    <div class="col-6 col-md-4 mb-3">
                                        <div class="fund-amount-btn">$10</div>
                                    </div>
                                    <div class="col-6 col-md-4 mb-3">
                                        <div class="fund-amount-btn">$25</div>
                                    </div>
                                    <div class="col-6 col-md-4 mb-3">
                                        <div class="fund-amount-btn">$50</div>
                                    </div>
                                    <div class="col-6 col-md-4 mb-3">
                                        <div class="fund-amount-btn selected">$100</div>
                                    </div>
                                    <div class="col-6 col-md-4 mb-3">
                                        <div class="fund-amount-btn">$250</div>
                                    </div>
                                    <div class="col-6 col-md-4 mb-3">
                                        <div class="fund-amount-btn">$500</div>
                                    </div>
                                </div>
                                
                                <div class="custom-amount">
                                    <label class="form-label">Or enter custom amount:</label>
                                    <div class="input-group mb-3">
                                        <span class="input-group-text">$</span>
                                        <input type="number" class="form-control" placeholder="Enter amount">
                                    </div>
                                </div>
                                
                                <div class="mt-4">
                                    <button class="btn btn-primary btn-lg w-100">Proceed to Payment</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-4">
                        <div class="card mb-4">
                            <div class="card-body">
                                <h5 class="card-title mb-3">Fund Summary</h5>
                                
                                <div class="d-flex justify-content-between mb-2">
                                    <span>Current Balance:</span>
                                    <span class="fw-bold">$15.00</span>
                                </div>
                                
                                <div class="d-flex justify-content-between mb-2">
                                    <span>Adding:</span>
                                    <span class="fw-bold text-success">$100.00</span>
                                </div>
                                
                                <hr>
                                
                                <div class="d-flex justify-content-between mb-2">
                                    <span>New Balance:</span>
                                    <span class="fw-bold">$115.00</span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title mb-3">Recent Transactions</h5>
                                
                                <div class="transaction-card">
                                    <div class="d-flex justify-content-between align-items-center mb-2">
                                        <span class="fw-bold">$50.00</span>
                                        <span class="transaction-status completed">Completed</span>
                                    </div>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span class="text-muted">PayPal - July 15, 2023</span>
                                        <i class="fas fa-check-circle text-success"></i>
                                    </div>
                                </div>
                                
                                <div class="transaction-card">
                                    <div class="d-flex justify-content-between align-items-center mb-2">
                                        <span class="fw-bold">$25.00</span>
                                        <span class="transaction-status completed">Completed</span>
                                    </div>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span class="text-muted">Credit Card - June 22, 2023</span>
                                        <i class="fas fa-check-circle text-success"></i>
                                    </div>
                                </div>
                                
                                <div class="transaction-card">
                                    <div class="d-flex justify-content-between align-items-center mb-2">
                                        <span class="fw-bold">$100.00</span>
                                        <span class="transaction-status completed">Completed</span>
                                    </div>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span class="text-muted">Bank Transfer - May 10, 2023</span>
                                        <i class="fas fa-check-circle text-success"></i>
                                    </div>
                                </div>
                                
                                <div class="mt-3 text-center">
                                    <a href="#" class="text-decoration-none">View All Transactions</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // JavaScript for the payment method selection
        document.querySelectorAll('.payment-card').forEach(card => {
            card.addEventListener('click', function() {
                // Remove selected class from all cards
                document.querySelectorAll('.payment-card').forEach(c => {
                    c.classList.remove('selected');
                });
                
                // Add selected class to clicked card
                this.classList.add('selected');
                
                // Check the radio button in this card
                const radio = this.querySelector('input[type="radio"]');
                if (radio) {
                    radio.checked = true;
                }
            });
        });
        
        // JavaScript for the amount selection
        document.querySelectorAll('.fund-amount-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                // Remove selected class from all buttons
                document.querySelectorAll('.fund-amount-btn').forEach(b => {
                    b.classList.remove('selected');
                });
                
                // Add selected class to clicked button
                this.classList.add('selected');
            });
        });
    </script>
</body>
</html> 