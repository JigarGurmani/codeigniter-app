<?php
$page_title = "Invite & Earn";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invite & Earn - Geo Rental Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary: #6f42c1;
            --primary-light: #8458e2;
            --primary-dark: #5e35b1;
            --secondary: #6c757d;
            --topbar-height: 60px;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f7ff;
            color: #333;
            padding-top: 70px;
        }
        .container-fluid {
            padding: 0;
        }

        /* Main Content */
        .main-content {
            background-color: #f5f7ff;
            min-height: 100vh;
            padding: 25px;
        }

        /* Card Styles */
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.05);
            margin-bottom: 25px;
        }
        
        .card-body {
            padding: 20px;
        }
        
        .affiliate-header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .affiliate-header h2 {
            font-weight: 700;
            color: var(--primary);
            margin-bottom: 15px;
        }
        
        .affiliate-header p {
            color: #6c757d;
            max-width: 800px;
            margin: 0 auto;
        }
        
        .stats-card {
            text-align: center;
            padding: 25px 15px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
            height: 100%;
        }
        
        .stats-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }
        
        .stats-icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            color: white;
            font-size: 24px;
        }
        
        .stats-value {
            font-size: 24px;
            font-weight: 700;
            color: #333;
            margin-bottom: 5px;
        }
        
        .stats-label {
            color: #6c757d;
            font-size: 14px;
        }
        
        .referral-link-card {
            background: linear-gradient(to right, #f8f9fa, #e9ecef);
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 25px;
        }
        
        .referral-link {
            display: flex;
            align-items: center;
            background-color: white;
            border-radius: 8px;
            padding: 10px 15px;
            margin-bottom: 15px;
            border: 1px solid #dee2e6;
        }
        
        .referral-link input {
            flex-grow: 1;
            border: none;
            padding: 8px 12px;
            background-color: transparent;
            font-size: 14px;
        }
        
        .referral-link input:focus {
            outline: none;
        }
        
        .referral-link button {
            background-color: var(--primary);
            color: white;
            border: none;
            border-radius: 5px;
            padding: 8px 15px;
            font-size: 14px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        
        .referral-link button:hover {
            background-color: var(--primary-dark);
        }
        
        .share-buttons {
            display: flex;
            justify-content: center;
            gap: 10px;
        }
        
        .share-button {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .share-button:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 10px rgba(0,0,0,0.1);
        }
        
        .share-facebook {
            background-color: #3b5998;
        }
        
        .share-twitter {
            background-color: #1da1f2;
        }
        
        .share-linkedin {
            background-color: #0077b5;
        }
        
        .share-whatsapp {
            background-color: #25d366;
        }
        
        .share-telegram {
            background-color: #0088cc;
        }
        
        .commission-rates {
            margin-top: 30px;
        }
        
        .commission-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            border-radius: 10px;
            overflow: hidden;
        }
        
        .commission-table th {
            background-color: var(--primary);
            color: white;
            padding: 15px;
            text-align: left;
        }
        
        .commission-table td {
            padding: 15px;
            border-bottom: 1px solid #dee2e6;
            background-color: white;
        }
        
        .commission-table tr:last-child td {
            border-bottom: none;
        }
        
        .commission-rate {
            font-weight: 600;
            color: var(--primary);
        }
        
        .referral-list {
            margin-top: 30px;
        }
        
        .referral-item {
            display: flex;
            align-items: center;
            background-color: white;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 15px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        }
        
        .referral-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background-color: var(--primary);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            font-weight: 600;
            margin-right: 15px;
        }
        
        .referral-info {
            flex-grow: 1;
        }
        
        .referral-name {
            font-weight: 600;
            color: #333;
            margin-bottom: 5px;
        }
        
        .referral-date {
            font-size: 13px;
            color: #6c757d;
        }
        
        .referral-status {
            font-size: 13px;
            padding: 5px 10px;
            border-radius: 20px;
            font-weight: 600;
        }
        
        .referral-status.active {
            background-color: rgba(40, 167, 69, 0.1);
            color: #28a745;
        }
        
        .referral-status.pending {
            background-color: rgba(255, 193, 7, 0.1);
            color: #ffc107;
        }
        
        .referral-amount {
            font-weight: 600;
            color: #28a745;
            margin-left: 15px;
        }
        
        .steps-section {
            margin: 40px 0;
        }
        
        .step-card {
            text-align: center;
            padding: 25px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.05);
            position: relative;
            height: 100%;
        }
        
        .step-number {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            position: absolute;
            top: -20px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 1;
        }
        
        .step-icon {
            font-size: 40px;
            color: var(--primary);
            margin-bottom: 20px;
        }
        
        .step-title {
            font-weight: 600;
            color: #333;
            margin-bottom: 10px;
        }
        
        .step-description {
            color: #6c757d;
            font-size: 14px;
        }
        
        .faq-section {
            margin-top: 40px;
        }
        
        .accordion-item {
            border: none;
            margin-bottom: 15px;
            border-radius: 10px;
            overflow: hidden;
        }
        
        .accordion-button {
            background-color: #fff;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
            font-weight: 600;
            color: #333;
            padding: 15px 20px;
        }
        
        .accordion-button:not(.collapsed) {
            background-color: var(--primary);
            color: white;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        }
        
        .accordion-button:focus {
            box-shadow: none;
            border-color: rgba(0,0,0,0.1);
        }
        
        .accordion-button::after {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%23333'%3e%3cpath fill-rule='evenodd' d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/%3e%3c/svg%3e");
        }
        
        .accordion-button:not(.collapsed)::after {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%23fff'%3e%3cpath fill-rule='evenodd' d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/%3e%3c/svg%3e");
        }
        
        .page-title {
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #dee2e6;
            font-weight: 600;
            color: #333;
        }
        
        /* Responsive Adjustments */
        @media (max-width: 768px) {
            body {
                padding-top: 80px;
            }
            
            .main-content {
                padding-top: 15px;
            }
            
            .stats-card {
                margin-bottom: 20px;
            }
            
            .step-card {
                margin-bottom: 30px;
            }
        }
    </style>
</head>
<body>
<?= $this->include('templates/navbardashboard') ?>
    
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 main-content">
                <?php if(session()->getFlashdata('success')): ?>
                    <div class="alert alert-success">
                        <?= session()->getFlashdata('success') ?>
                    </div>
                <?php endif; ?>
                
                <?php if(session()->getFlashdata('error')): ?>
                    <div class="alert alert-danger">
                        <?= session()->getFlashdata('error') ?>
                    </div>
                <?php endif; ?>
                
                <!-- Affiliate Content -->
                <div class="affiliate-header">
                    <h1 class="page-title">Invite & Earn</h1>
                    <p>Refer your friends and colleagues to our platform and earn up to 25% commission on their purchases. The more people you refer, the more you earn!</p>
                </div>
                
                <!-- Stats -->
                <div class="row mb-4">
                    <div class="col-md-3 mb-3 mb-md-0">
                        <div class="stats-card">
                            <div class="stats-icon">
                                <i class="fas fa-users"></i>
                            </div>
                            <div class="stats-value">47</div>
                            <div class="stats-label">Total Referrals</div>
                        </div>
                    </div>
                    
                    <div class="col-md-3 mb-3 mb-md-0">
                        <div class="stats-card">
                            <div class="stats-icon">
                                <i class="fas fa-check-circle"></i>
                            </div>
                            <div class="stats-value">32</div>
                            <div class="stats-label">Active Referrals</div>
                        </div>
                    </div>
                    
                    <div class="col-md-3 mb-3 mb-md-0">
                        <div class="stats-card">
                            <div class="stats-icon">
                                <i class="fas fa-dollar-sign"></i>
                            </div>
                            <div class="stats-value">$1,250</div>
                            <div class="stats-label">Total Earnings</div>
                        </div>
                    </div>
                    
                    <div class="col-md-3">
                        <div class="stats-card">
                            <div class="stats-icon">
                                <i class="fas fa-wallet"></i>
                            </div>
                            <div class="stats-value">$325</div>
                            <div class="stats-label">Available Balance</div>
                        </div>
                    </div>
                </div>
                
                <!-- Referral Link -->
                <div class="card">
                    <div class="card-body">
                        <h4 class="mb-3">Your Referral Link</h4>
                        <p class="text-muted mb-4">Share this unique link with your friends and earn commission when they sign up and make a purchase.</p>
                        
                        <div class="referral-link">
                            <input type="text" value="https://georentalpanel.com/ref/johndoe123" id="referralLink" readonly>
                            <button>
                                <i class="fas fa-copy me-1"></i> Copy
                            </button>
                        </div>
                        
                        <div class="text-center">
                            <p class="mb-2">Or share directly:</p>
                            <div class="share-buttons">
                                <div class="share-button share-facebook">
                                    <i class="fab fa-facebook-f"></i>
                                </div>
                                <div class="share-button share-twitter">
                                    <i class="fab fa-twitter"></i>
                                </div>
                                <div class="share-button share-linkedin">
                                    <i class="fab fa-linkedin-in"></i>
                                </div>
                                <div class="share-button share-whatsapp">
                                    <i class="fab fa-whatsapp"></i>
                                </div>
                                <div class="share-button share-telegram">
                                    <i class="fab fa-telegram-plane"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- How it Works Steps -->
                <div class="steps-section">
                    <h4 class="mb-4 text-center">How It Works</h4>
                    
                    <div class="row">
                        <div class="col-md-4 mb-4 mb-md-0">
                            <div class="step-card">
                                <div class="step-number">1</div>
                                <div class="step-icon">
                                    <i class="fas fa-link"></i>
                                </div>
                                <div class="step-title">Share Your Link</div>
                                <div class="step-description">
                                    Share your unique referral link with friends, on social media, or on your website.
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-4 mb-4 mb-md-0">
                            <div class="step-card">
                                <div class="step-number">2</div>
                                <div class="step-icon">
                                    <i class="fas fa-user-plus"></i>
                                </div>
                                <div class="step-title">Friends Sign Up</div>
                                <div class="step-description">
                                    When someone clicks your link and signs up, they're automatically linked to your account.
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-4">
                            <div class="step-card">
                                <div class="step-number">3</div>
                                <div class="step-icon">
                                    <i class="fas fa-money-bill-wave"></i>
                                </div>
                                <div class="step-title">Earn Commission</div>
                                <div class="step-description">
                                    Earn up to 25% commission on every purchase they make. Withdraw anytime!
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Commission Rates -->
                <div class="commission-rates">
                    <h4 class="mb-4">Commission Rates</h4>
                    
                    <div class="table-responsive">
                        <table class="commission-table">
                            <thead>
                                <tr>
                                    <th>Product/Service</th>
                                    <th>Commission Rate</th>
                                    <th>Example Earnings</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Panel Setup (Basic Plan)</td>
                                    <td><span class="commission-rate">15%</span></td>
                                    <td>$15 on a $100 purchase</td>
                                </tr>
                                <tr>
                                    <td>Panel Setup (Premium Plan)</td>
                                    <td><span class="commission-rate">20%</span></td>
                                    <td>$40 on a $200 purchase</td>
                                </tr>
                                <tr>
                                    <td>Panel Setup (Business Plan)</td>
                                    <td><span class="commission-rate">25%</span></td>
                                    <td>$75 on a $300 purchase</td>
                                </tr>
                                <tr>
                                    <td>Account Funds</td>
                                    <td><span class="commission-rate">10%</span></td>
                                    <td>$10 on a $100 deposit</td>
                                </tr>
                                <tr>
                                    <td>Child Panel Creation</td>
                                    <td><span class="commission-rate">15%</span></td>
                                    <td>$30 on a $200 setup</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <!-- Recent Referrals -->
                <div class="referral-list">
                    <h4 class="mb-4">Recent Referrals</h4>
                    
                    <div class="referral-item">
                        <div class="referral-avatar">JD</div>
                        <div class="referral-info">
                            <div class="referral-name">Jane Doe</div>
                            <div class="referral-date">Joined on Aug 12, 2023</div>
                        </div>
                        <div class="referral-status active">Active</div>
                        <div class="referral-amount">+$45.00</div>
                    </div>
                    
                    <div class="referral-item">
                        <div class="referral-avatar">MS</div>
                        <div class="referral-info">
                            <div class="referral-name">Mike Smith</div>
                            <div class="referral-date">Joined on Aug 5, 2023</div>
                        </div>
                        <div class="referral-status active">Active</div>
                        <div class="referral-amount">+$32.50</div>
                    </div>
                    
                    <div class="referral-item">
                        <div class="referral-avatar">AR</div>
                        <div class="referral-info">
                            <div class="referral-name">Amanda Rodriguez</div>
                            <div class="referral-date">Joined on Jul 28, 2023</div>
                        </div>
                        <div class="referral-status pending">Pending</div>
                        <div class="referral-amount">$0.00</div>
                    </div>
                    
                    <div class="referral-item">
                        <div class="referral-avatar">RJ</div>
                        <div class="referral-info">
                            <div class="referral-name">Robert Johnson</div>
                            <div class="referral-date">Joined on Jul 15, 2023</div>
                        </div>
                        <div class="referral-status active">Active</div>
                        <div class="referral-amount">+$75.00</div>
                    </div>
                    
                    <div class="text-center mt-4">
                        <a href="#" class="btn btn-outline-primary">View All Referrals</a>
                    </div>
                </div>
                
                <!-- FAQ Section -->
                <div class="faq-section">
                    <h4 class="mb-4">Frequently Asked Questions</h4>
                    
                    <div class="accordion" id="affiliateFAQ">
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingOne">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                    How do I get started with the affiliate program?
                                </button>
                            </h2>
                            <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#affiliateFAQ">
                                <div class="accordion-body">
                                    Getting started is easy! As a registered user, you automatically have access to the affiliate program. Simply copy your unique referral link from this page and start sharing it with your network. You'll earn commission on any purchases made by users who sign up through your link.
                                </div>
                            </div>
                        </div>
                        
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingTwo">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                    How and when do I get paid?
                                </button>
                            </h2>
                            <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#affiliateFAQ">
                                <div class="accordion-body">
                                    Commission is calculated and added to your affiliate balance as soon as your referral makes a purchase. You can withdraw your earnings once you reach the minimum withdrawal threshold of $50. We offer multiple payout methods including PayPal, bank transfer, and cryptocurrency.
                                </div>
                            </div>
                        </div>
                        
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingThree">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                    How long does the referral cookie last?
                                </button>
                            </h2>
                            <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#affiliateFAQ">
                                <div class="accordion-body">
                                    Our referral cookies last for 90 days. This means that if someone clicks your link but doesn't sign up immediately, you'll still get credit if they return and create an account within 90 days of their initial click.
                                </div>
                            </div>
                        </div>
                        
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingFour">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                    Can I promote the affiliate program on social media?
                                </button>
                            </h2>
                            <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#affiliateFAQ">
                                <div class="accordion-body">
                                    Yes, you can promote your referral link on social media platforms, your website, blog, or via email. However, please avoid spam tactics, misrepresentation of our services, or any form of deceptive marketing. We encourage honest and transparent promotion.
                                </div>
                            </div>
                        </div>
                        
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingFive">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                    What happens if I refer someone who already has an account?
                                </button>
                            </h2>
                            <div id="collapseFive" class="accordion-collapse collapse" aria-labelledby="headingFive" data-bs-parent="#affiliateFAQ">
                                <div class="accordion-body">
                                    In order to qualify for commission, your referral must be a new user who hasn't previously created an account with us. If someone clicks your link but logs into an existing account, it won't count as a referral.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 