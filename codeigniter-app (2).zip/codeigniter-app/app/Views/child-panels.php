<?php
$page_title = "Child Panels";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Child Panels - Geo Rental Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary: #6f42c1;
            --primary-light: #8458e2;
            --primary-dark: #5e35b1;
            --secondary: #6c757d;
            --topbar-height: 60px;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f7ff;
            color: #333;
            padding-top: 70px;
        }
        .container-fluid {
            padding: 0;
        }

        /* Main Content */
        .main-content {
            background-color: #f5f7ff;
            min-height: 100vh;
            padding: 25px;
        }

        /* Card Styles */
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.05);
            margin-bottom: 25px;
        }
        
        .card-body {
            padding: 20px;
        }
        
        .child-card {
            border: none;
            transition: all 0.3s ease;
            height: 100%;
            box-shadow: 0 2px 15px rgba(0,0,0,0.05);
        }
        
        .child-card:hover {
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            transform: translateY(-3px);
        }
        
        .child-card .card-header {
            font-weight: 600;
            text-align: center;
            font-size: 1.25rem;
            padding: 1rem;
            border-radius: 10px 10px 0 0;
            background-color: #f8f9fa;
        }
        
        .child-card .card-body {
            padding: 1.5rem;
        }
        
        .child-status {
            display: inline-block;
            padding: 0.35rem 0.65rem;
            border-radius: 20px;
            font-size: 0.875rem;
            font-weight: 600;
            margin-bottom: 10px;
        }
        
        .child-status.active {
            background-color: rgba(40, 167, 69, 0.1);
            color: #28a745;
        }
        
        .child-status.pending {
            background-color: rgba(255, 193, 7, 0.1);
            color: #ffc107;
        }
        
        .child-status.inactive {
            background-color: rgba(220, 53, 69, 0.1);
            color: #dc3545;
        }
        
        .child-info {
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
        }
        
        .child-info i {
            margin-right: 10px;
            width: 20px;
            color: var(--primary);
        }
        
        .btn-child {
            margin-top: 10px;
            border-radius: 5px;
            padding: 8px 15px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        .btn-child:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        
        .page-title {
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #dee2e6;
            font-weight: 600;
            color: #333;
        }
        
        /* Responsive Adjustments */
        @media (max-width: 768px) {
            body {
                padding-top: 80px;
            }
            
            .main-content {
                padding-top: 15px;
            }
        }
    </style>
</head>
<body>
<?= $this->include('templates/navbardashboard') ?>
    
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 main-content">
                <?php if(session()->getFlashdata('success')): ?>
                    <div class="alert alert-success">
                        <?= session()->getFlashdata('success') ?>
                    </div>
                <?php endif; ?>
                
                <?php if(session()->getFlashdata('error')): ?>
                    <div class="alert alert-danger">
                        <?= session()->getFlashdata('error') ?>
                    </div>
                <?php endif; ?>
                
                <!-- Child Panels Content -->
                <h1 class="page-title">Child Panels</h1>
                
                <div class="row mb-4">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">What are Child Panels?</h5>
                                <p>Child panels allow you to create and manage multiple SMM panels under your main account. You can create panels for your clients or resellers with custom branding and pricing, while managing them all from a single dashboard.</p>
                                <div class="mt-3">
                                    <a href="#" class="btn btn-primary">Create Child Panel</a>
                                    <a href="#" class="btn btn-outline-secondary ms-2">Learn More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <!-- Child Panel Item 1 -->
                    <div class="col-md-6 col-lg-4 mb-4">
                        <div class="card child-card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <span>client1.panel.com</span>
                                <span class="child-status active">Active</span>
                            </div>
                            <div class="card-body">
                                <div class="child-info">
                                    <i class="fas fa-user"></i>
                                    <span>Client: John's Marketing</span>
                                </div>
                                <div class="child-info">
                                    <i class="fas fa-server"></i>
                                    <span>Plan: Business</span>
                                </div>
                                <div class="child-info">
                                    <i class="fas fa-calendar-alt"></i>
                                    <span>Created: Mar 15, 2023</span>
                                </div>
                                <div class="child-info">
                                    <i class="fas fa-dollar-sign"></i>
                                    <span>Revenue: $1,250</span>
                                </div>
                                <div class="mt-3 d-flex justify-content-between">
                                    <a href="#" class="btn btn-sm btn-primary btn-child">Manage</a>
                                    <a href="#" class="btn btn-sm btn-outline-secondary btn-child">Stats</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Child Panel Item 2 -->
                    <div class="col-md-6 col-lg-4 mb-4">
                        <div class="card child-card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <span>reseller2.service.com</span>
                                <span class="child-status active">Active</span>
                            </div>
                            <div class="card-body">
                                <div class="child-info">
                                    <i class="fas fa-user"></i>
                                    <span>Client: Emma's Agency</span>
                                </div>
                                <div class="child-info">
                                    <i class="fas fa-server"></i>
                                    <span>Plan: Premium</span>
                                </div>
                                <div class="child-info">
                                    <i class="fas fa-calendar-alt"></i>
                                    <span>Created: Apr 28, 2023</span>
                                </div>
                                <div class="child-info">
                                    <i class="fas fa-dollar-sign"></i>
                                    <span>Revenue: $895</span>
                                </div>
                                <div class="mt-3 d-flex justify-content-between">
                                    <a href="#" class="btn btn-sm btn-primary btn-child">Manage</a>
                                    <a href="#" class="btn btn-sm btn-outline-secondary btn-child">Stats</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Child Panel Item 3 -->
                    <div class="col-md-6 col-lg-4 mb-4">
                        <div class="card child-card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <span>smm.clientsite.com</span>
                                <span class="child-status pending">Pending</span>
                            </div>
                            <div class="card-body">
                                <div class="child-info">
                                    <i class="fas fa-user"></i>
                                    <span>Client: David's SMM</span>
                                </div>
                                <div class="child-info">
                                    <i class="fas fa-server"></i>
                                    <span>Plan: Standard</span>
                                </div>
                                <div class="child-info">
                                    <i class="fas fa-calendar-alt"></i>
                                    <span>Created: Jun 10, 2023</span>
                                </div>
                                <div class="child-info">
                                    <i class="fas fa-exclamation-circle"></i>
                                    <span>Status: DNS Setup Pending</span>
                                </div>
                                <div class="mt-3 d-flex justify-content-between">
                                    <a href="#" class="btn btn-sm btn-warning btn-child">Complete Setup</a>
                                    <a href="#" class="btn btn-sm btn-outline-secondary btn-child">Guide</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 