<?php
$page_title = "Dashboard";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <!-- Add this within the <head> section -->
    <style>
        :root {
            --primary: #6f42c1;
            --primary-light: #8458e2;
            --primary-dark: #5e35b1;
            --secondary: #6c757d;
            /* --sidebar-width: 250px; */ /* Removed */
            --topbar-height: 60px;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f7ff;
            color: #333;
            padding-top: 0; /* Set top padding to zero */
        }
        .container-fluid {
            padding: 0;
        }

        /* Mobile Toggle Button CSS Removed */
        /* Sidebar Styles CSS Removed */
        /* Sidebar h3 CSS Removed */
        /* User-info (sidebar specific) CSS Removed */
        /* Category-header (sidebar specific) CSS Removed */
        /* Sidebar .nav-link CSS Removed */

        /* Main Content */
        .main-content {
            background-color: #f5f7ff;
            min-height: 100vh;
            padding: 25px;
            /* margin-left: var(--sidebar-width); */ /* Removed */
            /* transition: margin-left 0.3s ease; */ /* Removed */
        }

        /* .main-content.full-width CSS Removed */

        /* Top Navbar */
        .top-navbar {
            position: static; /* Change from fixed to static */
            top: 0;
            right: 0;
            left: 0;
            height: var(--topbar-height);
            background: white;
            border-bottom: 1px solid rgba(0,0,0,0.08);
            z-index: 1030;
            display: flex;
            align-items: center;
            justify-content: flex-end;
            padding: 0 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.03);
            width: 100%;
       
        /* Dropdown Menu */
        .dropdown-menu {
            background: white !important;
            border: 1px solid rgba(40, 167, 69, 0.2) !important;
            border-radius: 15px !important;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1) !important;
            padding: 10px 0 !important;
            margin-top: 10px !important;
        }
        
        .dropdown-item {
            padding: 10px 20px !important;
            transition: all 0.3s ease !important;
            border-radius: 10px !important;
            margin: 2px 10px !important;
        }
        
        .dropdown-item:hover {
            background: linear-gradient(145deg, rgba(40, 167, 69, 0.1), rgba(32, 201, 151, 0.1)) !important;
            color:rgb(193, 202, 69) !important;
            transform: translateX(5px) !important;
        }
        
        /* Navigation Menu Styling - Now moved to navbar */
        .nav-pills .nav-link {
            color: #007bff;
            border-radius: 5px;
            margin: 0 5px;
            transition: background-color 0.3s ease, color 0.3s ease;
        }
        
        .nav-pills .nav-link:hover {
            background-color: #e2e6ea;
        }
        
        .nav-pills .nav-link.active {
            background-color: #007bff;
            color: white;
        }
        
        .icon-container {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            background-color: #e9ecef;
            border-radius: 50%;
            margin-right: 10px;
        }
        
        /* Balance Cards Styling */
        .balance-card {
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin: 10px 0;
            text-align: center;
        }
        
        .balance-card .amount {
            font-size: 24px;
            font-weight: bold;
            color: #333;
        }
        
        .balance-card .label {
            font-size: 14px;
            color: #666;
        }
        
        /* Responsive Adjustments */
        @media (max-width: 768px) {
            .nav-menu {
                flex-direction: column;
                align-items: center;
            }
        
            .balance-card {
                margin: 10px;
            }
            
            /* Add more top padding to account for larger navbar with menu */
            body {
                padding-top: 80px;
            }
            
            .main-content {
                padding-top: 15px;
            }
        }
        
        /* Sidebar Overlay CSS Removed */
        
        /* Rest of existing styles */
        .main-content .alert {
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            border: none;
        }
        
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.05);
            margin-bottom: 25px;
        }
        
        .card-body {
            padding: 20px;
        }
        
        .display-4 {
            font-weight: 700;
            color: var(--primary);
            font-size: 2.2rem;
        }
        
        .plan-card {
            border: none;
            transition: all 0.3s;
            height: 100%;
            box-shadow: 0 2px 15px rgba(0,0,0,0.05);
        }
        
        .plan-card:hover {
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            transform: translateY(-3px);
        }
        
        .plan-card .card-header {
            font-weight: bold;
            text-align: center;
            font-size: 1.25rem;
            padding: 1rem;
            border-radius: 10px 10px 0 0;
        }
        
        .plan-card .card-body {
            padding: 1.5rem;
        }
        
        .plan-price {
            font-size: 2rem;
            font-weight: bold;
            margin-bottom: 1rem;
            text-align: center;
        }
        
        .plan-features {
            list-style-type: none;
            padding-left: 0;
            margin-bottom: 1.5rem;
        }
        
        .plan-features li {
            padding: 0.5rem 0;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .plan-features li:last-child {
            border-bottom: none;
        }
        
        .plan-features li::before {
            content: "✓ ";
            color: #28a745;
            font-weight: bold;
        }
        
        .page-title {
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #dee2e6;
            font-weight: 600;
            color: #333;
        }
        
        .btn {
            border-radius: 8px;
            font-weight: 500;
        }
        
        .btn-primary {
            background-color: var(--primary);
            border-color: var(--primary);
        }
        
        .btn-primary:hover {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
        }
        
        .btn-info {
            background-color: #17a2b8;
            border-color: #17a2b8;
        }
        
        .table {
            border-radius: 10px;
            overflow: hidden;
        }
        
        .table thead th {
            background-color: rgba(111, 66, 193, 0.05);
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.75rem;
            letter-spacing: 0.5px;
            color: #555;
            padding: 12px 20px;
            border-top: none;
        }
        
        .table td {
            vertical-align: middle;
            padding: 12px 20px;
        }
        
        .badge {
            font-size: 0.75rem;
            font-weight: 600;
            padding: 0.35rem 0.65rem;
            border-radius: 6px;
        }
        
        .form-control:focus {
            box-shadow: 0 0 0 3px rgba(111, 66, 193, 0.25);
            border-color: var(--primary);
        }

        /* Styles for the new content sections (previously sidebar content) */
        .user-details-section {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 25px;
            /* text-align: center; */ /* Optional: if you want user name/email centered */
        }
        .user-details-section .user-name {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--primary);
            margin-bottom: 5px;
        }
        .user-details-section .user-email {
            font-size: 0.9rem;
            color: #666;
        }

        .content-section {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 25px;
        }
        .content-section h4 {
            font-size: 1.1rem;
            text-transform: uppercase;
            color: var(--primary);
            font-weight: 600;
            padding-bottom: 10px;
            margin-bottom: 15px;
            border-bottom: 1px solid rgba(0,0,0,0.1);
            letter-spacing: 0.5px;
        }
        .content-section .nav-link {
            color: #555;
            padding: 10px 15px;
            font-weight: 500;
            display: flex;
            align-items: center;
            border-radius: 5px;
            text-decoration: none;
            margin-bottom: 5px;
            transition: background-color 0.2s ease, color 0.2s ease;
        }
        .content-section .nav-link:hover {
            background-color: rgba(111, 66, 193, 0.05);
            color: var(--primary);
        }
        .content-section .nav-link.active {
            background-color: rgba(111, 66, 193, 0.1);
            color: var(--primary);
            font-weight: 600;
        }
        .content-section .nav-link i {
            font-size: 16px;
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }

        /* Desktop Navigation Styles */
        .desktop-nav-container {
            background-color:rgb(54, 201, 10);
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            margin-bottom: 20px;
            position: sticky;
            top: 56px; /* Match navbar height */
            z-index: 1020; /* Below navbar but above content */
        }

        .desktop-nav {
            padding: 110px 0;
        }

        .desktop-nav .nav-pills {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
        }

        

        .desktop-nav .nav-pills .nav-link {
            background-color: rgb(255, 247, 238); 
            color: white;
            padding: 10px 16px;
            border-radius: 5px;
            color: #495057;
            font-weight: 500;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            margin: 0 5px;
        }

        .desktop-nav .nav-pills .nav-link i {
            margin-right: 8px;
            font-size: 16px;
        }

        .desktop-nav .nav-pills .nav-link:hover {
            background-color: #ff5722; /* Change to a more visible color */
            color: white;
            transform: translateY(-2px);
        }

        .desktop-nav .nav-pills .nav-link.active {
            background: linear-gradient(145deg, #28a745, #20c997) !important;
            color: white !important;
            padding: 10px 16px !important;
            border-radius: 20px !important;
            text-decoration: none !important;
            font-weight: 600 !important;
            box-shadow: 
                0 6px 12px rgba(40, 167, 69, 0.3),
                0 3px 6px rgba(0, 0, 0, 0.1),
                inset 0 1px 0 rgba(255, 255, 255, 0.2) !important;
            border: 1px solid #1e7e34 !important;
            position: relative !important;
            overflow: hidden !important;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275) !important;
            transform: translateY(0) !important;
        }
        
        .desktop-nav .nav-pills .nav-link.active::before {
            content: '' !important;
            position: absolute !important;
            top: 0 !important;
            left: -100% !important;
            width: 100% !important;
            height: 100% !important;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent) !important;
            transition: left 0.5s !important;
        }
        
        .desktop-nav .nav-pills .nav-link.active:hover {
            background: linear-gradient(145deg, #20c997, #17a2b8) !important;
            color: white !important;
            transform: translateY(-2px) !important;
            box-shadow: 
                0 8px 16px rgba(40, 167, 69, 0.4),
                0 4px 8px rgba(0, 0, 0, 0.15),
                inset 0 1px 0 rgba(255, 255, 255, 0.3) !important;
            border-color: #138496 !important;
        }
        
        .desktop-nav .nav-pills .nav-link.active:hover::before {
            left: 100% !important;
        }

        /* Adjust main content padding to account for fixed desktop nav */
        @media (min-width: 782px) {
            .desktop-nav-container {
                background-color:rgba(240, 238, 243, 0.53) !important;
            }
            body {
                padding-top: 70px; /* Adjusted to accommodate fixed navbar + desktop nav */
            }
        }
    </style>
</head>
<body>
<?= $this->include('templates/navbardashboard') ?>
    
   
    <!-- Mobile Toggle Button HTML Removed -->
    <!-- Sidebar Overlay for Mobile HTML Removed -->
    
    <div class="container-fluid">
        <div class="row">
            <!-- Main Content - now takes full width -->
            <div class="col-12 main-content" id="mainContent">
                <?php if(session()->getFlashdata('success')): ?>
                    <div class="alert alert-success">
                        <?= session()->getFlashdata('success') ?>
                    </div>
                <?php endif; ?>
                
                <?php if(session()->getFlashdata('error')): ?>
                    <div class="alert alert-danger">
                        <?= session()->getFlashdata('error') ?>
                    </div>
                <?php endif; ?>
                
                <!-- Balance Cards -->
                <div class="row mb-4">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-body d-flex align-items-center">
                                <div class="icon-container bg-light rounded-circle p-3 me-3">
                                    <i class="fas fa-wallet text-primary"></i>
                                </div>
                                <div>
                                    <h5 class="card-title mb-0">Rs.15</h5>
                                    <p class="card-text text-muted">Your Balance</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-body d-flex align-items-center">
                                <div class="icon-container bg-light rounded-circle p-3 me-3">
                                    <i class="fas fa-money-bill-wave text-success"></i>
                                </div>
                                <div>
                                    <h5 class="card-title mb-0">Rs.9,015</h5>
                                    <p class="card-text text-muted">Total deposit</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                        <!-- Nameservers Section -->
                        <div class="mb-4">
                            <h5>Nameservers</h5>
                            <div class="alert" style="background-color: #d1f5f9; border: none; border-radius: 8px;">
                                <p class="mb-2"><strong>Point your domain to these name servers before placing order</strong></p>
                                <ul class="list-unstyled mb-0">
                                    <li>ns1.dns-parking.com</li>
                                    <li>ns2.dns-parking.com</li>
                                </ul>
                            </div>
                        </div>
                        
                        <!-- Domain Name Form -->
                        <div class="mb-4">
                            <h5>Domain name</h5>
                            <div class="mb-3">
                                <input type="text" class="form-control" placeholder="yourdomain.com">
                            </div>
                            
                            <div class="alert" style="background-color: #ffebda; border: none; border-radius: 8px;">
                                <p class="mb-0"><strong>Charge: Rs.3,000</strong></p>
                            </div>
                            
                            <button type="submit" class="btn w-100" style="background-color: #00bcd4; color: white; font-weight: 600;">Submit</button>
                        </div>
                    </div>
                </div>
                    
                    <!-- Plans Tab -->
                    <div class="tab-pane fade" id="plans">
                        <h1 class="page-title">Choose Your Plan</h1>
                        
                        <div class="row">
                            <!-- Plan A -->
                            <div class="col-md-6 col-lg-3 mb-4">
                                <div class="card plan-card">
                                    <div class="card-header bg-primary text-white">Plan - A</div>
                                    <div class="card-body">
                                        <div class="plan-price text-primary">$10</div>
                                        <h6 class="text-muted text-center mb-4">Starter Panel</h6>
                                        <ul class="plan-features">
                                            <li>5000 Orders Limit</li>
                                            <li>Unlimited API</li>
                                            <li>Weekly Backup</li>
                                            <li>Premium Hosting</li>
                                            <li>Basic Theme</li>
                                            <li>24/7 Support</li>
                                        </ul>
                                        <a href="<?= site_url('submit-order?plan=A') ?>" class="btn btn-primary w-100">Start Now</a>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Plan B -->
                            <div class="col-md-6 col-lg-3 mb-4">
                                <div class="card plan-card">
                                    <div class="card-header bg-info text-white">Plan - B</div>
                                    <div class="card-body">
                                        <div class="plan-price text-info">$20</div>
                                        <h6 class="text-muted text-center mb-4">Premium Plan</h6>
                                        <ul class="plan-features">
                                            <li>20000 Orders Limit</li>
                                            <li>Unlimited API</li>
                                            <li>Premium Hosting</li>
                                            <li>10+ Themes</li>
                                            <li>SSL Protection</li>
                                            <li>24/7 Support</li>
                                        </ul>
                                        <a href="<?= site_url('submit-order?plan=B') ?>" class="btn btn-info w-100 text-white">Start Now</a>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Plan C -->
                            <div class="col-md-6 col-lg-3 mb-4">
                                <div class="card plan-card">
                                    <div class="card-header bg-success text-white">Plan - C</div>
                                    <div class="card-body">
                                        <div class="plan-price text-success">$35</div>
                                        <h6 class="text-muted text-center mb-4">Business Plan</h6>
                                        <ul class="plan-features">
                                            <li>50000 Orders Limit</li>
                                            <li>Website SEO</li>
                                            <li>Secured VPS</li>
                                            <li>20+ Themes</li>
                                            <li>Unlimited API</li>
                                            <li>24×7 Support</li>
                                        </ul>
                                        <a href="<?= site_url('submit-order?plan=C') ?>" class="btn btn-success w-100">Start Now</a>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Plan D -->
                            <div class="col-md-6 col-lg-3 mb-4">
                                <div class="card plan-card">
                                    <div class="card-header bg-danger text-white">Plan - D</div>
                                    <div class="card-body">
                                        <div class="plan-price text-danger">$60</div>
                                        <h6 class="text-muted text-center mb-4">Economy Plan</h6>
                                        <ul class="plan-features">
                                            <li>Unlimited Orders</li>
                                            <li>Website SEO</li>
                                            <li>Secured VPS</li>
                                            <li>25+ Themes</li>
                                            <li>Unlimited API</li>
                                            <li>24×7 Support</li>
                                        </ul>
                                        <a href="<?= site_url('submit-order?plan=D') ?>" class="btn btn-danger w-100">Start Now</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Orders Tab -->
                    <div class="tab-pane fade" id="orders">
                        <h1 class="page-title">My Orders</h1>
                        
                        <?php if(empty($orders)): ?>
                            <div class="alert alert-info">
                                You haven't placed any orders yet. <a href="#plans" data-bs-toggle="tab">Click here</a> to buy a plan.
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Order ID</th>
                                            <th>Plan</th>
                                            <th>Payment Method</th>
                                            <th>Amount</th>
                                            <th>Order Date</th>
                                            <th>Payment Date</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($orders as $order): ?>
                                        <tr>
                                            <td>#<?= $order['id'] ?></td>
                                            <td>Plan <?= $order['plan'] ?></td>
                                            <td><?= ucfirst(str_replace('_', ' ', $order['payment_method'])) ?></td>
                                            <td>$<?= number_format($order['total_amount'], 2) ?></td>
                                            <td><?= date('M d, Y', strtotime($order['order_date'])) ?></td>
                                            <td>
                                                <?= $order['payment_date'] ? date('M d, Y', strtotime($order['payment_date'])) : 'Pending' ?>
                                            </td>
                                            <td>
                                                <?php if($order['status'] == 'pending'): ?>
                                                    <span class="badge bg-warning">Pending</span>
                                                <?php elseif($order['status'] == 'confirmed'): ?>
                                                    <span class="badge bg-success">Confirmed</span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary"><?= ucfirst($order['status']) ?></span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Profile Tab -->
                    <div class="tab-pane fade" id="profile">
                        <h1 class="page-title">My Profile</h1>
                        
                        <div class="card">
                            <div class="card-body">
                                <form>
                                    <div class="row mb-3">
                                        <label class="col-sm-3 col-form-label">Username:</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" value="<?= $user['username'] ?>" readonly>
                                        </div>
                                    </div>
                                    
                                    <div class="row mb-3">
                                        <label class="col-sm-3 col-form-label">Full Name:</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" value="<?= $user['full_name'] ?>" readonly>
                                        </div>
                                    </div>
                                    
                                    <div class="row mb-3">
                                        <label class="col-sm-3 col-form-label">Email:</label>
                                        <div class="col-sm-9">
                                            <input type="email" class="form-control" value="<?= $user['email'] ?>" readonly>
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-sm-9 offset-sm-3">
                                            <button type="button" class="btn btn-primary" disabled>Edit Profile (Coming Soon)</button>
                                            <button type="button" class="btn btn-secondary" disabled>Change Password (Coming Soon)</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<!-- Modify the navigation menu structure -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="nav nav-pills nav-menu">
            <li class="nav-item">
                <a class="nav-link" href="#">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">Features</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">Pricing</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">About</a>
            </li>
        </ul>
    </div>
</nav>