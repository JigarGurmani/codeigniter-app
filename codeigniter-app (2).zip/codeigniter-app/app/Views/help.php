<?php
$page_title = "Help";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Help & Support - Geo Rental Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary: #6f42c1;
            --primary-light: #8458e2;
            --primary-dark: #5e35b1;
            --secondary: #6c757d;
            --topbar-height: 60px;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f7ff;
            color: #333;
            padding-top: 70px;
        }
        .container-fluid {
            padding: 0;
        }

        /* Main Content */
        .main-content {
            background-color: #f5f7ff;
            min-height: 100vh;
            padding: 25px;
        }

        /* Card Styles */
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.05);
            margin-bottom: 25px;
        }
        
        .card-body {
            padding: 20px;
        }
        
        .help-card {
            border: none;
            transition: all 0.3s ease;
            height: 100%;
            box-shadow: 0 2px 15px rgba(0,0,0,0.05);
            text-align: center;
            padding: 30px 20px;
        }
        
        .help-card:hover {
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            transform: translateY(-3px);
        }
        
        .help-icon {
            width: 80px;
            height: 80px;
            margin: 0 auto 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary-light), var(--primary));
            color: white;
            font-size: 32px;
        }
        
        .help-card h4 {
            margin-bottom: 15px;
            font-weight: 600;
            color: #333;
        }
        
        .help-card p {
            color: #6c757d;
            margin-bottom: 20px;
        }
        
        .faq-card {
            border: none;
            margin-bottom: 15px;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.03);
        }
        
        .faq-card .card-header {
            background-color: #fff;
            border: none;
            padding: 15px 20px;
            cursor: pointer;
            position: relative;
        }
        
        .faq-card .card-header h5 {
            margin: 0;
            font-weight: 600;
            color: #333;
            font-size: 16px;
            padding-right: 25px;
        }
        
        .faq-card .card-header::after {
            content: '+';
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 20px;
            color: var(--primary);
            transition: transform 0.3s ease;
        }
        
        .faq-card .card-header.active::after {
            content: '-';
        }
        
        .faq-card .card-body {
            border-top: 1px solid rgba(0,0,0,0.05);
            padding: 15px 20px;
            color: #6c757d;
        }
        
        .contact-form .form-control {
            border-radius: 8px;
            padding: 12px 15px;
            border: 1px solid #e1e5eb;
            margin-bottom: 15px;
        }
        
        .contact-form .form-control:focus {
            box-shadow: 0 0 0 3px rgba(111, 66, 193, 0.25);
            border-color: var(--primary);
        }
        
        .page-title {
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #dee2e6;
            font-weight: 600;
            color: #333;
        }
        
        /* Knowledge Base Styles */
        .kb-categories {
            margin-bottom: 30px;
        }
        
        .kb-category {
            padding: 15px;
            border-radius: 8px;
            background-color: #fff;
            margin-bottom: 15px;
            border-left: 4px solid var(--primary);
            transition: all 0.3s ease;
            cursor: pointer;
        }
        
        .kb-category:hover {
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transform: translateY(-2px);
        }
        
        .kb-category h5 {
            margin-bottom: 5px;
            font-weight: 600;
            color: #333;
        }
        
        .kb-category p {
            margin-bottom: 0;
            color: #6c757d;
            font-size: 14px;
        }
        
        /* Responsive Adjustments */
        @media (max-width: 768px) {
            body {
                padding-top: 80px;
            }
            
            .main-content {
                padding-top: 15px;
            }
        }
    </style>
</head>
<body>
<?= $this->include('templates/navbardashboard') ?>
    
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 main-content">
                <?php if(session()->getFlashdata('success')): ?>
                    <div class="alert alert-success">
                        <?= session()->getFlashdata('success') ?>
                    </div>
                <?php endif; ?>
                
                <?php if(session()->getFlashdata('error')): ?>
                    <div class="alert alert-danger">
                        <?= session()->getFlashdata('error') ?>
                    </div>
                <?php endif; ?>
                
                <!-- Help Content -->
                <h1 class="page-title">Help & Support</h1>
                
                <!-- Support Options -->
                <div class="row mb-5">
                    <div class="col-md-4 mb-4">
                        <div class="card help-card">
                            <div class="help-icon">
                                <i class="fas fa-comments"></i>
                            </div>
                            <h4>Live Chat Support</h4>
                            <p>Get instant help from our support team through live chat. Available 24/7.</p>
                            <button class="btn btn-primary">Start Chat</button>
                        </div>
                    </div>
                    
                    <div class="col-md-4 mb-4">
                        <div class="card help-card">
                            <div class="help-icon">
                                <i class="fas fa-ticket-alt"></i>
                            </div>
                            <h4>Support Tickets</h4>
                            <p>Create a support ticket for complex issues or technical assistance.</p>
                            <button class="btn btn-primary">Open Ticket</button>
                        </div>
                    </div>
                    
                    <div class="col-md-4 mb-4">
                        <div class="card help-card">
                            <div class="help-icon">
                                <i class="fas fa-book"></i>
                            </div>
                            <h4>Knowledge Base</h4>
                            <p>Browse our extensive knowledge base for tutorials and guides.</p>
                            <button class="btn btn-primary">View Articles</button>
                        </div>
                    </div>
                </div>
                
                <!-- FAQ Section -->
                <div class="card mb-5">
                    <div class="card-body">
                        <h3 class="mb-4">Frequently Asked Questions</h3>
                        
                        <div class="faq-card">
                            <div class="card-header">
                                <h5>How do I set up a new panel?</h5>
                            </div>
                            <div class="card-body">
                                <p>To set up a new panel, navigate to the Dashboard and click on "Set-Up New Panel". Enter your domain name, select your preferred plan, and follow the on-screen instructions. Make sure your domain is pointed to our nameservers before proceeding with the setup.</p>
                            </div>
                        </div>
                        
                        <div class="faq-card">
                            <div class="card-header">
                                <h5>What payment methods do you accept?</h5>
                            </div>
                            <div class="card-body">
                                <p>We accept various payment methods including PayPal, credit/debit cards, bank transfers, and cryptocurrencies. You can add funds to your account by navigating to the "Add Fund" section and selecting your preferred payment method.</p>
                            </div>
                        </div>
                        
                        <div class="faq-card">
                            <div class="card-header">
                                <h5>How do I create a child panel?</h5>
                            </div>
                            <div class="card-body">
                                <p>To create a child panel, go to the "Child Panels" section and click on "Create Child Panel". You'll need to specify a domain name, select a plan, and configure the panel settings. Child panels allow you to resell our services under your own brand.</p>
                            </div>
                        </div>
                        
                        <div class="faq-card">
                            <div class="card-header">
                                <h5>What is the affiliate program?</h5>
                            </div>
                            <div class="card-body">
                                <p>Our affiliate program allows you to earn commissions by referring new users to our platform. When someone signs up using your referral link and makes a purchase, you'll receive a percentage of their payment. You can find your unique referral link in the "Invite & Earn" section.</p>
                            </div>
                        </div>
                        
                        <div class="faq-card">
                            <div class="card-header">
                                <h5>How long does it take to set up a panel?</h5>
                            </div>
                            <div class="card-body">
                                <p>Panel setup typically takes 1-3 hours after your domain's DNS changes have propagated. In some cases, it may take up to 24 hours depending on DNS propagation time. You can check the status of your panel setup in the "My Panels" section.</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Knowledge Base Section -->
                <div class="card mb-5">
                    <div class="card-body">
                        <h3 class="mb-4">Knowledge Base Categories</h3>
                        
                        <div class="kb-categories">
                            <div class="kb-category">
                                <h5>Getting Started</h5>
                                <p>Learn the basics of setting up and managing your panel.</p>
                            </div>
                            
                            <div class="kb-category">
                                <h5>Panel Management</h5>
                                <p>Detailed guides on panel configuration and maintenance.</p>
                            </div>
                            
                            <div class="kb-category">
                                <h5>Payment & Billing</h5>
                                <p>Information about payment methods, invoices, and refunds.</p>
                            </div>
                            
                            <div class="kb-category">
                                <h5>API Documentation</h5>
                                <p>Technical documentation for integrating with our API.</p>
                            </div>
                            
                            <div class="kb-category">
                                <h5>Security & Privacy</h5>
                                <p>Best practices for securing your panel and protecting user data.</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Contact Form -->
                <div class="card">
                    <div class="card-body">
                        <h3 class="mb-4">Contact Us</h3>
                        
                        <form class="contact-form">
                            <div class="mb-3">
                                <label for="subject" class="form-label">Subject</label>
                                <input type="text" class="form-control" id="subject" placeholder="Enter subject">
                            </div>
                            
                            <div class="mb-3">
                                <label for="category" class="form-label">Category</label>
                                <select class="form-select" id="category">
                                    <option>Technical Support</option>
                                    <option>Billing Issue</option>
                                    <option>Feature Request</option>
                                    <option>General Inquiry</option>
                                    <option>Other</option>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label for="message" class="form-label">Message</label>
                                <textarea class="form-control" id="message" rows="5" placeholder="Describe your issue or question in detail"></textarea>
                            </div>
                            
                            <div class="mb-3">
                                <label for="attachment" class="form-label">Attachment (optional)</label>
                                <input class="form-control" type="file" id="attachment">
                            </div>
                            
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 