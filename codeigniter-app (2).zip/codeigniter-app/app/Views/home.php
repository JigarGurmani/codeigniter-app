<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Geo Rental Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>

        @media (max-width: 767px) {
            .hero { padding: 80px 0 30px 0; } /* Increased top padding for hero if navbar height changes */
            /* Ensure content doesn't overlap navbar on mobile */
            body {
                height: auto;
                overflow-x: hidden;
                width: 100%;
            }
        }

        body { 
            background:rgb(255, 255, 255); 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            /* padding-top is now managed in navbar.php */
        }
        .hero {
            background: linear-gradient(120deg,rgb(43, 40, 214) 60%,rgb(53, 27, 199) 100%);
            color: #fff;
            padding: 150px 0 60px 0; /* Top padding increased to accommodate fixed navbar */
            text-align: center;
            position: relative;
            overflow: hidden;
        }
        .hero::after {
            content: '';
            position: absolute;
            top: 0; left: 0; width: 100%; height: 100%;
            background: url('https://www.transparenttextures.com/patterns/cubes.png');
            opacity: 0.08;
        }
        
        /* Enhanced Get Started Button */
        .hero .btn:first-child {
            background: linear-gradient(145deg, #28a745, #20c997) !important;
            color: white !important;
            border: 2px solid #1e7e34 !important;
            border-radius: 30px !important;
            padding: 12px 36px !important;
            font-weight: 600 !important;
            text-decoration: none !important;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275) !important;
            transform: translateY(0) !important;
            box-shadow: 0 8px 15px rgba(40, 167, 69, 0.3), 0 4px 6px rgba(0, 0, 0, 0.1) !important;
            position: relative !important;
            overflow: hidden !important;
            z-index: 10 !important;
            cursor: pointer !important;
        }
        
        .hero .btn:first-child:hover {
            background: linear-gradient(145deg, #20c997, #17a2b8) !important;
            color: white !important;
            transform: translateY(-3px) !important;
            box-shadow: 0 12px 25px rgba(40, 167, 69, 0.4), 0 6px 12px rgba(0, 0, 0, 0.15) !important;
            border-color: #138496 !important;
        }
        
        .hero .btn:first-child:active {
            transform: translateY(-1px) !important;
            box-shadow: 0 4px 8px rgba(40, 167, 69, 0.3), 0 2px 4px rgba(0, 0, 0, 0.1) !important;
        }
        
        .brand { font-size: 2.5rem; font-weight: bold; letter-spacing: 2px; }
        .navbar { box-shadow: 0 2px 8px rgba(0,0,0,0.03); }
        .btn-main { background: #fff; color: #007bff; border-radius: 30px; font-weight: 600; padding: 12px 36px; transition: 0.2s; }
        .btn-main:hover { background: #007bff; color: #fff; border: 1px solid #fff; }
        .features { margin-top: 50px; padding: 30px 0; }
        .feature-box {
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 4px 24px rgba(0,0,0,0.07);
            padding: 40px 25px;
            margin-bottom: 30px;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .feature-box:hover {
            transform: translateY(-8px) scale(1.03);
            box-shadow: 0 8px 32px rgba(0,0,0,0.12);
        }
        .feature-icon {
            height: 60px;
            width: 60px;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: rgba(13, 110, 253, 0.1);
            border-radius: 50%;
            margin: 0 auto;
            margin-bottom: 18px;
        }
        .lead { font-size: 1.35rem; }
        .section-title {
            font-weight: 700;
            color: #333;
            margin-bottom: 1.5rem;
            position: relative;
        }
        .key-features {
            background-color: #f8f9fa;
            padding: 60px 0;
            margin-top: 30px;
        }
        .key-feature-item {
            background: #fff;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
            height: 100%;
        }
        .key-feature-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }
        .key-feature-icon {
            color:rgb(5, 133, 15);
            font-size: 1.8rem;
            margin-bottom: 15px;
        }
       
    </style>
</head>
<body>
    <?= $this->include('templates/navbar') ?>
    <section class="hero">
        <div class="container position-relative">
            <h1 class="display-4 fw-bold">Build a Powerful Rental Panel</h1>
            <p class="lead mb-4">Rental Panel gives your customers an easy-to-use SMM Rental Panel where they can place Millions of orders.</p>
            <div class="d-flex gap-3 justify-content-center">
                <a href="<?= site_url('login') ?>" class="btn btn-lg shadow-lg px-4 py-2 fw-bold" style="background-color: #28a745; color: white; border-radius: 30px; text-decoration: none; border: 2px solid #1e7e34; transition: all 0.3s ease;">Get Started</a>
                <a href="https://demoversion.news" target="_blank" class="btn btn-outline-primary btn-lg shadow rounded-pill px-4 py-2 fw-bold text-white live-demo-btn" style="position: relative; z-index: 10; pointer-events: auto; cursor: pointer;">Live Demo</a>
            </div>
        </div>
    </section>
    
    <section class="features container mt-5" id="features">
        <div class="text-center mb-4">
            <h2 class="section-title">Why Geo Rental Panel?</h2>
            <p class="text-muted">Geo Rental Panel offers reliable service plans to meet your SMM panel needs.</p>
        </div>
        
        <div class="row g-4 mt-2">
            <div class="col-md-3 text-center">
                <div class="feature-icon">
                    <i class="fas fa-user-shield text-primary"></i>
                </div>
                <h5 class="fw-bold">Superb User Panel</h5>
                <p class="small">Provide your customers with a user-friendly panel where they can place millions of orders.</p>
            </div>
            
            <div class="col-md-3 text-center">
                <div class="feature-icon">
                    <i class="fas fa-credit-card text-primary"></i>
                </div>
                <h5 class="fw-bold">Multi Payment Methods</h5>
                <p class="small">Effortlessly accept all payment methods that suit your requirements.</p>
            </div>
            
            <div class="col-md-3 text-center">
                <div class="feature-icon">
                    <i class="fas fa-tasks text-primary"></i>
                </div>
                <h5 class="fw-bold">Efficient Order Processing</h5>
                <p class="small">Link multiple APIs to enable automated order processing.</p>
            </div>
            
            <div class="col-md-3 text-center">
                <div class="feature-icon">
                    <i class="fas fa-cogs text-primary"></i>
                </div>
                <h5 class="fw-bold">Powerful Admin Panel</h5>
                <p class="small">Take full control of your business with a powerful admin interface.</p>
            </div>
        </div>
    </section>
    
    <!-- Key Features Section -->
    <section class="key-features" id="key-features">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="section-title">Key Features</h2>
                <p class="text-muted">Explore all the powerful tools and solutions available on our platform.</p>
            </div>
            
            <div class="row g-4">
                <!-- First Row -->
                <div class="col-md-3">
                    <div class="key-feature-item text-center">
                        <div class="key-feature-icon">
                            <i class="fas fa-users"></i>
                        </div>
                        <h5 class="fw-bold">Reseller with Providers</h5>
                        <p class="small">Integrate both auto and manual orders seamlessly with external API providers.</p>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="key-feature-item text-center">
                        <div class="key-feature-icon">
                            <i class="fas fa-shield-alt"></i>
                        </div>
                        <h5 class="fw-bold">API Security</h5>
                        <p class="small">Protect your accounts with secure API keys for better legal security.</p>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="key-feature-item text-center">
                        <div class="key-feature-icon">
                            <i class="fas fa-lock"></i>
                        </div>
                        <h5 class="fw-bold">Unlimited Providers</h5>
                        <p class="small">Integrate as many API providers as needed with no limits.</p>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="key-feature-item text-center">
                        <div class="key-feature-icon">
                            <i class="fas fa-shopping-cart"></i>
                        </div>
                        <h5 class="fw-bold">Bulk Ordering</h5>
                        <p class="small">Use API to place orders at once using the bulk order feature.</p>
                    </div>
                </div>
                
                <!-- Second Row -->
                <div class="col-md-3">
                    <div class="key-feature-item text-center">
                        <div class="key-feature-icon">
                            <i class="fas fa-child"></i>
                        </div>
                        <h5 class="fw-bold">Child Panels</h5>
                        <p class="small">Sell your own panels by offering easy-to-use child panels.</p>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="key-feature-item text-center">
                        <div class="key-feature-icon">
                            <i class="fas fa-rss"></i>
                        </div>
                        <h5 class="fw-bold">Drip Feed</h5>
                        <p class="small">Schedule orders gradually to ensure organic growth appearance.</p>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="key-feature-item text-center">
                        <div class="key-feature-icon">
                            <i class="fas fa-sort-amount-up"></i>
                        </div>
                        <h5 class="fw-bold">Mass Order API</h5>
                        <p class="small">Use API to place thousands of orders simultaneously.</p>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="key-feature-item text-center">
                        <div class="key-feature-icon">
                            <i class="fas fa-credit-card"></i>
                        </div>
                        <h5 class="fw-bold">Multiple Gateways</h5>
                        <p class="small">Accept payments via PayPal, Stripe, Bitcoin and more.</p>
                    </div>
                </div>
                
                <!-- Third Row -->
                <div class="col-md-3">
                    <div class="key-feature-item text-center">
                        <div class="key-feature-icon">
                            <i class="fas fa-clock"></i>
                        </div>
                        <h5 class="fw-bold">Real-time Status</h5>
                        <p class="small">Track order status instantly with real-time provider updates.</p>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="key-feature-item text-center">
                        <div class="key-feature-icon">
                            <i class="fas fa-ban"></i>
                        </div>
                        <h5 class="fw-bold">Auto Cancel</h5>
                        <p class="small">If orders create errors, they auto-cancel after your set time.</p>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="key-feature-item text-center">
                        <div class="key-feature-icon">
                            <i class="fas fa-recycle"></i>
                        </div>
                        <h5 class="fw-bold">Refill</h5>
                        <p class="small">Supports both auto and manual refills depending on service type.</p>
                    </div>
                </div>
                 <div class="col-md-3">
                    <div class="key-feature-item text-center">
                        <div class="key-feature-icon">
                            <i class="fas fa-edit"></i>
                        </div>
                        <h5 class="fw-bold">Bulk Service Editor</h5>
                        <p class="small">This tool allows you quickly edit multiple services at once.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

     <!-- Security & Server Section -->
    <section class="security-server py-5" id="security">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="section-title">Security & Server</h2>
                <p class="text-muted">Secure servers and top-notch infrastructure for data protection.</p>
            </div>
            
            <div class="row g-4">
                <div class="col-md-3">
                    <div class="key-feature-item text-center">
                        <div class="key-feature-icon">
                            <i class="fas fa-shield-alt"></i>
                        </div>
                        <h5 class="fw-bold">DDoS Protection</h5>
                        <p class="small">Enhanced attack protection with robust protection against DDoS threats.</p>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="key-feature-item text-center">
                        <div class="key-feature-icon">
                            <i class="fas fa-database"></i>
                        </div>
                        <h5 class="fw-bold">Regular Backup</h5>
                        <p class="small">All your data remain securely stored, with automatic backups for peace of mind.</p>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="key-feature-item text-center">
                        <div class="key-feature-icon">
                            <i class="fas fa-globe"></i>
                        </div>
                        <h5 class="fw-bold">Your own Domain</h5>
                        <p class="small">Use your own domain for an even better brand identity in your business.</p>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="key-feature-item text-center">
                        <div class="key-feature-icon">
                            <i class="fas fa-certificate"></i>
                        </div>
                        <h5 class="fw-bold">Free SSL Certificate</h5>
                        <p class="small">Every panel comes with a complimentary SSL certificate for security.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Pricing Plan Section -->
    <section class="pricing-plan py-5" id="pricing">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="section-title">Pricing Plan</h2>
                <p class="text-muted">Explore our affordable pricing plans tailored to suit your needs. Choose the perfect plan!</p>
            </div>
            
            <div class="row g-4 justify-content-center">
                <!-- Plan A -->
                <div class="col-md-3">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-body text-center p-4">
                            <h4 class="fw-bold mb-1">Plan - A</h4>
                            <p class="text-muted small mb-3">Starter Panel</p>
                            <h2 class="display-6 fw-bold mb-3">$10.00 <span class="text-muted small fw-normal">/mo</span></h2>
                            <a href="<?= site_url('start-plan/A') ?>" class="btn btn-primary w-100 py-2 mb-4">Start Now</a>
                            
                            <p class="text-start fw-bold mb-2 small">Includes:</p>
                            <ul class="list-unstyled text-start small">
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i> 5000 Orders Limit</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Unlimited API</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Weekly Backup</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Premium Hosting</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Basic Theme</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i> 24/7 Support</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Weekly Updates</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Best 4 Resellers</li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <!-- Plan B -->
                <div class="col-md-3">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-body text-center p-4">
                            <h4 class="fw-bold mb-1">Plan - B</h4>
                            <p class="text-muted small mb-3">Premium Plan</p>
                            <h2 class="display-6 fw-bold mb-3">$20.00 <span class="text-muted small fw-normal">/mo</span></h2>
                            <a href="<?= site_url('start-plan/B') ?>" class="btn btn-primary w-100 py-2 mb-4">Start Now</a>
                            
                            <p class="text-start fw-bold mb-2 small">Includes:</p>
                            <ul class="list-unstyled text-start small">
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i> 20000 Orders Limit</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Unlimited API</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Premium Hosting</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i> 10+ Themes</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i> SSL Protection</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i> 24/7 Support</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Weekly Backup</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Best 4 Bigginer</li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <!-- Plan C -->
                <div class="col-md-3">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-body text-center p-4">
                            <h4 class="fw-bold mb-1">Plan - C</h4>
                            <p class="text-muted small mb-3">Business Plan</p>
                            <h2 class="display-6 fw-bold mb-3">$35.00 <span class="text-muted small fw-normal">/mo</span></h2>
                            <a href="<?= site_url('start-plan/C') ?>" class="btn btn-primary w-100 py-2 mb-4">Start Now</a>
                            
                            <p class="text-start fw-bold mb-2 small">Includes:</p>
                            <ul class="list-unstyled text-start small">
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i> 50000 Orders Limit</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Website SEO</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Secured VPS</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i> 20+ Themes</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Unlimited API</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i> 24×7 Support</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Daily Backup</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Unlimited Bandwidth</li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <!-- Plan D -->
                <div class="col-md-3">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-body text-center p-4">
                            <h4 class="fw-bold mb-1">Plan - D</h4>
                            <p class="text-muted small mb-3">Economy Plan</p>
                            <h2 class="display-6 fw-bold mb-3">$60.00 <span class="text-muted small fw-normal">/mo</span></h2>
                            <a href="<?= site_url('start-plan/D') ?>" class="btn btn-primary w-100 py-2 mb-4">Start Now</a>
                            
                            <p class="text-start fw-bold mb-2 small">Includes:</p>
                            <ul class="list-unstyled text-start small">
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Unlimited Orders</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Website SEO</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Secured VPS</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i> 25+ Themes</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Unlimited API</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i> 24×7 Support</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Daily Backup</li>
                                <li class="mb-2"><i class="fas fa-check text-success me-2"></i> Free Domain (online)</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    
    <!-- FAQ Section -->
    <section class="faq-section py-5 bg-light" id="faq">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="section-title">Frequently Asked Questions</h2>
                <p class="text-muted">Find answers to the most common questions about our SMM panel, services, payments, and support in our FAQ section.</p>
            </div>
            
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <div class="accordion" id="faqAccordion">
                        <!-- Question 1 -->
                        <div class="card border-0 mb-3 shadow-sm">
                            <div class="card-header bg-white border-0 p-0" id="headingOne">
                                <button class="btn btn-link text-dark text-decoration-none d-flex justify-content-between w-100 p-3" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                    <span class="fw-bold">Is there any setup fee?</span>
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                            <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-bs-parent="#faqAccordion">
                                <div class="card-body">
                                    No, there is no setup fee. You only pay for the plan you choose, and you can get started immediately after payment.
                                </div>
                            </div>
                        </div>
                        
                        <!-- Question 2 -->
                        <div class="card border-0 mb-3 shadow-sm">
                            <div class="card-header bg-white border-0 p-0" id="headingTwo">
                                <button class="btn btn-link text-dark text-decoration-none d-flex justify-content-between w-100 p-3" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                    <span class="fw-bold">Do I need to use my own domain name?</span>
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                            <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-bs-parent="#faqAccordion">
                                <div class="card-body">
                                    While you can use our subdomain for free, we recommend using your own domain for better branding and professional appearance. Some plans include a free domain name.
                                </div>
                            </div>
                        </div>
                        
                        <!-- Question 3 -->
                        <div class="card border-0 mb-3 shadow-sm">
                            <div class="card-header bg-white border-0 p-0" id="headingThree">
                                <button class="btn btn-link text-dark text-decoration-none d-flex justify-content-between w-100 p-3" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                    <span class="fw-bold">Do I need any web hosting?</span>
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                            <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-bs-parent="#faqAccordion">
                                <div class="card-body">
                                    No, you don't need to purchase separate web hosting. All our plans include premium hosting with the necessary resources to run your panel efficiently.
                                </div>
                            </div>
                        </div>
                        
                        <!-- Question 4 -->
                        <div class="card border-0 mb-3 shadow-sm">
                            <div class="card-header bg-white border-0 p-0" id="headingFour">
                                <button class="btn btn-link text-dark text-decoration-none d-flex justify-content-between w-100 p-3" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                    <span class="fw-bold">Do you sell followers or views?</span>
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                            <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-bs-parent="#faqAccordion">
                                <div class="card-body">
                                    We provide the platform for you to sell services. You can connect with various service providers through our API integration system and offer their services to your customers.
                                </div>
                            </div>
                        </div>
                        
                        <!-- Question 5 -->
                        <div class="card border-0 mb-3 shadow-sm">
                            <div class="card-header bg-white border-0 p-0" id="headingFive">
                                <button class="btn btn-link text-dark text-decoration-none d-flex justify-content-between w-100 p-3" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                    <span class="fw-bold">What payment methods do you accept?</span>
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                            <div id="collapseFive" class="collapse" aria-labelledby="headingFive" data-bs-parent="#faqAccordion">
                                <div class="card-body">
                                    We accept various payment methods including credit/debit cards, PayPal, cryptocurrency (Bitcoin, Ethereum), and bank transfers. Contact us if you need a specific payment option.
                                </div>
                            </div>
                        </div>
                        
                        <!-- Question 6 -->
                        <div class="card border-0 mb-3 shadow-sm">
                            <div class="card-header bg-white border-0 p-0" id="headingSix">
                                <button class="btn btn-link text-dark text-decoration-none d-flex justify-content-between w-100 p-3" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
                                    <span class="fw-bold">Are these panels for lifetime?</span>
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                            <div id="collapseSix" class="collapse" aria-labelledby="headingSix" data-bs-parent="#faqAccordion">
                                <div class="card-body">
                                    Our panels are subscription-based with monthly or annual billing options. As long as your subscription is active, you'll have full access to all features included in your plan.
                                </div>
                            </div>
                        </div>
                        
                        <!-- Question 7 -->
                        <div class="card border-0 mb-3 shadow-sm">
                            <div class="card-header bg-white border-0 p-0" id="headingSeven">
                                <button class="btn btn-link text-dark text-decoration-none d-flex justify-content-between w-100 p-3" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
                                    <span class="fw-bold">Can I add unlimited sellers?</span>
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                            <div id="collapseSeven" class="collapse" aria-labelledby="headingSeven" data-bs-parent="#faqAccordion">
                                <div class="card-body">
                                    Yes, you can add as many sellers or resellers as you want. There's no limit on the number of user accounts you can create in your panel.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Add some CSS for the FAQ section -->
    <style>
        .faq-section {
            background-color: #f8f9fa;
        }
        .faq-section .card {
            border-radius: 10px;
            overflow: hidden;
            transition: all 0.3s ease;
        }
        .faq-section .card:hover {
            box-shadow: 0 10px 30px rgba(0,0,0,0.1) !important;
        }
        .faq-section .card-header button {
            border-radius: 10px;
        }
        .faq-section .card-header button:hover {
            background-color: rgba(51, 206, 12, 0.42);
        }
        .faq-section .card-header button:focus {
            box-shadow: none;
        }
        .faq-section .card-header button[aria-expanded="true"] .fa-plus {
            transform: rotate(180deg);
        }
        .faq-section .fa-plus {
            transition: transform 0.3s ease;
        }
    </style>
    
    <!-- Contact Us Section -->
    <section class="contact-section py-5 bg-white" id="contact">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body p-5">
                            <div class="text-center mb-4">
                                <h2 class="section-title">Connect with Us!</h2>
                                <p class="text-muted">Get in touch with us for any inquiries, support, or assistance. We're here to help you with your needs!</p>
                            </div>
                            
                            <form>
                                <div class="mb-3">
                                    <label for="fullName" class="form-label">Full Name</label>
                                    <input type="text" class="form-control" id="fullName" placeholder="Name">
                                </div>
                                
                                <div class="mb-3">
                                    <label for="emailAddress" class="form-label">Email address</label>
                                    <input type="email" class="form-control" id="emailAddress" placeholder="Email">
                                </div>
                                
                                <div class="mb-3">
                                    <label for="regarding" class="form-label">Regarding</label>
                                    <input type="text" class="form-control" id="regarding" placeholder="Support">
                                </div>
                                
                                <div class="mb-4">
                                    <label for="message" class="form-label">Message</label>
                                    <textarea class="form-control" id="message" rows="5" placeholder="Message"></textarea>
                                </div>
                                
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-primary py-3">Let's Talk</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
   
    <!-- Add some CSS for the Contact section -->
    <style>

        .contact-section {
            background-color: #f8f9fa;
        }
        .contact-section .card {
            border-radius: 15px;
            overflow: hidden;
        }
        .contact-section .form-control {
            padding: 12px 15px;
            border-radius: 8px;
            border: 1px solid #dee2e6;
            font-size: 16px;
        }
        .contact-section .form-control:focus {
            box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.15);
            border-color: #86b7fe;
        }
        .contact-section .btn-primary {
            background:rgba(9, 13, 236, 0.7);
            border-color:rgba(11, 14, 211, 0.57);
            border-radius: 8px;
            font-weight: 600;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
        }
        .contact-section .btn-primary:hover {
            background:rgb(5, 180, 14);
            border-color:rgb(238, 255, 0);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
    </style>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h4>Geo Rental Panel</h4>
                    <p>The most reliable and modern rental management solution for your business.</p>
                </div>
                <div class="col-md-3">
                    <h5>Quick Links</h5>
                    <ul class="list-unstyled">
                        <li><a href="#" class="text-white">Home</a></li>
                        <li><a href="#features" class="text-white">Features</a></li>
                        <li><a href="#pricing" class="text-white">Pricing</a></li>
                        <li><a href="#contact" class="text-white">Contact</a></li>
                    </ul>
                </div>
                <div class="col-md-3">
                    <h5>Contact Us</h5>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-envelope me-2"></i> info@georentalpanel.com</li>
                        <li><i class="fas fa-phone me-2"></i> +1 (555) 123-4567</li>
                    </ul>
                </div>
            </div>
            <hr>
            <div class="text-center">
                <p class="mb-0">© 2017-2025 Geo Rental Panel. All rights reserved.</p>
            </div>
        </div>
    </footer>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Ensure the "Get Started" button works correctly
        document.addEventListener('DOMContentLoaded', function() {
            const getStartedBtn = document.querySelector('a[href*="login"]');
            if (getStartedBtn && !getStartedBtn.classList.contains('live-demo-btn')) {
                getStartedBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    window.location.href = '<?= site_url('login') ?>';
                });
            }
            
            // Ensure Live Demo button works
            const liveDemoBtn = document.querySelector('.live-demo-btn');
            if (liveDemoBtn) {
                liveDemoBtn.addEventListener('click', function(e) {
                    // Let the default behavior work (opening the link)
                    console.log('Live Demo button clicked');
                });
            }
        });
    </script>
    <style>
        .live-demo-btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
            border: 2px solid #667eea !important;
            color: white !important;
            text-decoration: none !important;
            transition: all 0.3s ease !important;
            position: relative !important;
            z-index: 10 !important;
            pointer-events: auto !important;
            cursor: pointer !important;
        }
        
        .live-demo-btn:hover {
            background: linear-gradient(135deg, #764ba2 0%, #667eea 100%) !important;
            transform: translateY(-3px) !important;
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4) !important;
            color: white !important;
            text-decoration: none !important;
        }
        
        .live-demo-btn:active {
            transform: translateY(-1px) !important;
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3) !important;
        }
        
        .live-demo-btn:focus {
            outline: none !important;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.3) !important;
        }
        
        /* Ensure no overlapping elements */
        .hero {
            position: relative;
            z-index: 1;
        }
        
        .hero .container {
            position: relative;
            z-index: 2;
        }
        
        /* Remove any conflicting JavaScript */
        .live-demo-btn * {
            pointer-events: none;
        }
    </style>
</body>
</html>
