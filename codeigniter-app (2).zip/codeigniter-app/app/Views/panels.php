<?php
$page_title = "My Panels";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Panels - Geo Rental Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary: #6f42c1;
            --primary-light: #8458e2;
            --primary-dark: #5e35b1;
            --secondary: #6c757d;
            --topbar-height: 60px;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f7ff;
            color: #333;
            padding-top: 70px;
        }
        .container-fluid {
            padding: 0;
        }

        /* Main Content */
        .main-content {
            background-color: #f5f7ff;
            min-height: 100vh;
            padding: 25px;
        }

        /* Card Styles */
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.05);
            margin-bottom: 25px;
        }
        
        .card-body {
            padding: 20px;
        }
        
        .panel-card {
            border: none;
            transition: all 0.3s ease;
            height: 100%;
            box-shadow: 0 2px 15px rgba(0,0,0,0.05);
        }
        
        .panel-card:hover {
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            transform: translateY(-3px);
        }
        
        .panel-card .card-header {
            font-weight: 600;
            text-align: center;
            font-size: 1.25rem;
            padding: 1rem;
            border-radius: 10px 10px 0 0;
            background-color: #f8f9fa;
        }
        
        .panel-card .card-body {
            padding: 1.5rem;
        }
        
        .panel-status {
            display: inline-block;
            padding: 0.35rem 0.65rem;
            border-radius: 20px;
            font-size: 0.875rem;
            font-weight: 600;
            margin-bottom: 10px;
        }
        
        .panel-status.active {
            background-color: rgba(40, 167, 69, 0.1);
            color: #28a745;
        }
        
        .panel-status.pending {
            background-color: rgba(255, 193, 7, 0.1);
            color: #ffc107;
        }
        
        .panel-status.inactive {
            background-color: rgba(220, 53, 69, 0.1);
            color: #dc3545;
        }
        
        .panel-info {
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
        }
        
        .panel-info i {
            margin-right: 10px;
            width: 20px;
            color: var(--primary);
        }
        
        .btn-panel {
            margin-top: 10px;
            border-radius: 5px;
            padding: 8px 15px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        .btn-panel:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        
        .page-title {
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #dee2e6;
            font-weight: 600;
            color: #333;
        }
        
        /* Responsive Adjustments */
        @media (max-width: 768px) {
            body {
                padding-top: 80px;
            }
            
            .main-content {
                padding-top: 15px;
            }
        }
    </style>
</head>
<body>
<?= $this->include('templates/navbardashboard') ?>
    
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 main-content">
                <?php if(session()->getFlashdata('success')): ?>
                    <div class="alert alert-success">
                        <?= session()->getFlashdata('success') ?>
                    </div>
                <?php endif; ?>
                
                <?php if(session()->getFlashdata('error')): ?>
                    <div class="alert alert-danger">
                        <?= session()->getFlashdata('error') ?>
                    </div>
                <?php endif; ?>
                
                <!-- My Panels Content -->
                <h1 class="page-title">My Panels</h1>
                
                <div class="row">
                    <!-- Panel Item 1 -->
                    <div class="col-md-6 col-lg-4 mb-4">
                        <div class="card panel-card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <span>geopanel.com</span>
                                <span class="panel-status active">Active</span>
                            </div>
                            <div class="card-body">
                                <div class="panel-info">
                                    <i class="fas fa-server"></i>
                                    <span>Plan: Premium</span>
                                </div>
                                <div class="panel-info">
                                    <i class="fas fa-calendar-alt"></i>
                                    <span>Created: Jun 10, 2023</span>
                                </div>
                                <div class="panel-info">
                                    <i class="fas fa-clock"></i>
                                    <span>Expires: Jun 10, 2024</span>
                                </div>
                                <div class="panel-info">
                                    <i class="fas fa-chart-line"></i>
                                    <span>Status: Running</span>
                                </div>
                                <div class="mt-3 d-flex justify-content-between">
                                    <a href="#" class="btn btn-sm btn-primary btn-panel">Manage</a>
                                    <a href="#" class="btn btn-sm btn-outline-secondary btn-panel">Renew</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Panel Item 2 -->
                    <div class="col-md-6 col-lg-4 mb-4">
                        <div class="card panel-card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <span>smmservice.com</span>
                                <span class="panel-status pending">Pending</span>
                            </div>
                            <div class="card-body">
                                <div class="panel-info">
                                    <i class="fas fa-server"></i>
                                    <span>Plan: Business</span>
                                </div>
                                <div class="panel-info">
                                    <i class="fas fa-calendar-alt"></i>
                                    <span>Created: Aug 15, 2023</span>
                                </div>
                                <div class="panel-info">
                                    <i class="fas fa-clock"></i>
                                    <span>Status: DNS Setup Pending</span>
                                </div>
                                <div class="panel-info">
                                    <i class="fas fa-chart-line"></i>
                                    <span>Progress: 70%</span>
                                </div>
                                <div class="mt-3 d-flex justify-content-between">
                                    <a href="#" class="btn btn-sm btn-warning btn-panel">Check Status</a>
                                    <a href="#" class="btn btn-sm btn-outline-secondary btn-panel">Support</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Add New Panel Card -->
                    <div class="col-md-6 col-lg-4 mb-4">
                        <div class="card panel-card h-100">
                            <div class="card-body d-flex flex-column align-items-center justify-content-center text-center">
                                <div class="mb-3" style="width: 80px; height: 80px; background-color: #f8f9fa; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                                    <i class="fas fa-plus" style="font-size: 30px; color: #6f42c1;"></i>
                                </div>
                                <h5>Set Up New Panel</h5>
                                <p class="text-muted">Create a new SMM Panel with your preferred domain and configuration.</p>
                                <a href="<?= site_url('dashboard') ?>" class="btn btn-primary mt-2">Get Started</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 