<?php
$page_title = "Register";
$error = session()->getFlashdata('error');
$success = session()->getFlashdata('success');
$errors = session()->getFlashdata('errors');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | Geo Rental Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #6f42c1;
            --primary-light: #8458e2;
            --primary-dark: #5e35b1;
        }
        body {
            background-color: #f5f7ff;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
            padding: 3rem 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .register-container {
            max-width: 500px;
            width: 90%;
            margin: 0 auto;
        }
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        .card-header {
            background-color: var(--primary);
            color: white;
            text-align: center;
            border-radius: 10px 10px 0 0 !important;
            padding: 1.5rem;
        }
        .logo-container {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-bottom: 1rem;
        }
        .logo {
            height: 50px;
            width: 50px;
            background-color: white;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary);
            font-size: 30px;
            font-weight: bold;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .card-body {
            padding: 2rem;
        }
        .form-control {
            border-radius: 8px;
            padding: 10px 15px;
            height: auto;
        }
        .form-control:focus {
            box-shadow: 0 0 0 3px rgba(111, 66, 193, 0.25);
            border-color: var(--primary);
        }
        .btn-primary {
            background-color: var(--primary);
            border-color: var(--primary);
            border-radius: 8px;
            padding: 10px 15px;
            font-weight: 600;
        }
        .btn-primary:hover {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
        }
        .card-footer {
            background-color: white;
            text-align: center;
            border-top: none;
            padding: 1rem 2rem 1.5rem;
            border-radius: 0 0 10px 10px !important;
        }
        .alert {
            border-radius: 8px;
            font-size: 14px;
        }
        .invalid-feedback {
            font-size: 0.775rem;
        }
    </style>
</head>
<body>
    <div class="register-container">
        <div class="card">
            <div class="card-header">
                <div class="logo-container">
                    <div class="logo">
                        <i class="fas fa-cubes"></i>
                    </div>
                </div>
                <h4 class="mb-0">Create Your Account</h4>
            </div>
            <div class="card-body">
                <?php if($error): ?>
                <div class="alert alert-danger" role="alert">
                    <i class="fas fa-exclamation-circle me-2"></i><?= $error ?>
                </div>
                <?php endif; ?>
                
                <?php if($success): ?>
                <div class="alert alert-success" role="alert">
                    <i class="fas fa-check-circle me-2"></i><?= $success ?>
                </div>
                <?php endif; ?>
                
                <form action="<?= site_url('register/create') ?>" method="post">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="username" class="form-label">Username</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light"><i class="fas fa-user"></i></span>
                                <input type="text" class="form-control <?= isset($errors['username']) ? 'is-invalid' : '' ?>" 
                                id="username" name="username" value="<?= old('username') ?>" required>
                            </div>
                            <?php if(isset($errors['username'])): ?>
                                <div class="invalid-feedback d-block"><?= $errors['username'] ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="full_name" class="form-label">Full Name</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light"><i class="fas fa-id-card"></i></span>
                                <input type="text" class="form-control <?= isset($errors['full_name']) ? 'is-invalid' : '' ?>" 
                                id="full_name" name="full_name" value="<?= old('full_name') ?>" required>
                            </div>
                            <?php if(isset($errors['full_name'])): ?>
                                <div class="invalid-feedback d-block"><?= $errors['full_name'] ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="email" class="form-label">Email</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light"><i class="fas fa-envelope"></i></span>
                                <input type="email" class="form-control <?= isset($errors['email']) ? 'is-invalid' : '' ?>" 
                                id="email" name="email" value="<?= old('email') ?>" required>
                            </div>
                            <?php if(isset($errors['email'])): ?>
                                <div class="invalid-feedback d-block"><?= $errors['email'] ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="phone" class="form-label">Phone</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light"><i class="fas fa-phone"></i></span>
                                <input type="text" class="form-control <?= isset($errors['phone']) ? 'is-invalid' : '' ?>" 
                                id="phone" name="phone" value="<?= old('phone') ?>" required>
                            </div>
                            <?php if(isset($errors['phone'])): ?>
                                <div class="invalid-feedback d-block"><?= $errors['phone'] ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="company_name" class="form-label">Company Name (Optional)</label>
                        <div class="input-group">
                            <span class="input-group-text bg-light"><i class="fas fa-building"></i></span>
                            <input type="text" class="form-control" id="company_name" name="company_name" value="<?= old('company_name') ?>">
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="password" class="form-label">Password</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light"><i class="fas fa-lock"></i></span>
                                <input type="password" class="form-control <?= isset($errors['password']) ? 'is-invalid' : '' ?>" 
                                id="password" name="password" required>
                            </div>
                            <?php if(isset($errors['password'])): ?>
                                <div class="invalid-feedback d-block"><?= $errors['password'] ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6 mb-4">
                            <label for="password_confirm" class="form-label">Confirm Password</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light"><i class="fas fa-lock"></i></span>
                                <input type="password" class="form-control <?= isset($errors['password_confirm']) ? 'is-invalid' : '' ?>" 
                                id="password_confirm" name="password_confirm" required>
                            </div>
                            <?php if(isset($errors['password_confirm'])): ?>
                                <div class="invalid-feedback d-block"><?= $errors['password_confirm'] ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-primary w-100">Create Account</button>
                </form>
            </div>
            <div class="card-footer">
                Already have an account? <a href="<?= site_url('login') ?>" class="text-decoration-none text-primary">Login now</a>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 