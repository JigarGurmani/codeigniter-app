<?php
$page_title = "Reviews";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reviews - Geo Rental Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary: #6f42c1;
            --primary-light: #8458e2;
            --primary-dark: #5e35b1;
            --secondary: #6c757d;
            --topbar-height: 60px;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f7ff;
            color: #333;
            padding-top: 70px;
        }
        .container-fluid {
            padding: 0;
        }

        /* Main Content */
        .main-content {
            background-color: #f5f7ff;
            min-height: 100vh;
            padding: 25px;
        }

        /* Card Styles */
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.05);
            margin-bottom: 25px;
        }
        
        .card-body {
            padding: 20px;
        }
        
        .review-card {
            border: none;
            transition: all 0.3s ease;
            height: 100%;
            box-shadow: 0 2px 15px rgba(0,0,0,0.05);
            margin-bottom: 25px;
            border-radius: 10px;
            overflow: hidden;
        }
        
        .review-card:hover {
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            transform: translateY(-3px);
        }
        
        .review-header {
            display: flex;
            align-items: center;
            padding: 15px 20px;
            background-color: #f8f9fa;
            border-bottom: 1px solid rgba(0,0,0,0.05);
        }
        
        .review-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background-color: var(--primary);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            font-weight: 600;
            margin-right: 15px;
        }
        
        .review-user {
            flex-grow: 1;
        }
        
        .review-user h5 {
            margin-bottom: 0;
            font-weight: 600;
            color: #333;
        }
        
        .review-user p {
            margin-bottom: 0;
            font-size: 14px;
            color: #6c757d;
        }
        
        .review-rating {
            display: flex;
            align-items: center;
        }
        
        .review-stars {
            color: #ffc107;
            font-size: 16px;
            margin-right: 5px;
        }
        
        .review-date {
            font-size: 14px;
            color: #6c757d;
        }
        
        .review-content {
            padding: 20px;
            background-color: #fff;
        }
        
        .review-text {
            margin-bottom: 15px;
            color: #333;
            line-height: 1.6;
        }
        
        .review-photos {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 15px;
        }
        
        .review-photo {
            width: 80px;
            height: 80px;
            border-radius: 5px;
            object-fit: cover;
            cursor: pointer;
            transition: transform 0.3s ease;
        }
        
        .review-photo:hover {
            transform: scale(1.05);
        }
        
        .review-footer {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 20px;
            background-color: #f8f9fa;
            border-top: 1px solid rgba(0,0,0,0.05);
        }
        
        .review-actions button {
            background: none;
            border: none;
            color: #6c757d;
            font-size: 14px;
            cursor: pointer;
            margin-right: 15px;
            transition: color 0.3s ease;
        }
        
        .review-actions button:hover {
            color: var(--primary);
        }
        
        .review-actions button i {
            margin-right: 5px;
        }
        
        .review-stats {
            display: flex;
            align-items: center;
        }
        
        .review-stat {
            display: flex;
            align-items: center;
            margin-left: 15px;
            color: #6c757d;
            font-size: 14px;
        }
        
        .review-stat i {
            margin-right: 5px;
        }
        
        .rating-summary {
            margin-bottom: 30px;
        }
        
        .rating-summary-header {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .rating-summary-score {
            font-size: 48px;
            font-weight: 700;
            color: #333;
            margin-right: 20px;
            line-height: 1;
        }
        
        .rating-summary-stars {
            display: flex;
            flex-direction: column;
        }
        
        .rating-summary-stars .stars {
            color: #ffc107;
            font-size: 24px;
            margin-bottom: 5px;
        }
        
        .rating-summary-stars .reviews-count {
            color: #6c757d;
        }
        
        .rating-bars {
            margin-top: 20px;
        }
        
        .rating-bar {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }
        
        .rating-bar-label {
            width: 80px;
            display: flex;
            align-items: center;
        }
        
        .rating-bar-label i {
            color: #ffc107;
            margin-right: 5px;
        }
        
        .rating-bar-progress {
            flex-grow: 1;
            height: 8px;
            background-color: #e9ecef;
            border-radius: 4px;
            margin: 0 15px;
            overflow: hidden;
        }
        
        .rating-bar-progress-inner {
            height: 100%;
            background: linear-gradient(to right, var(--primary-light), var(--primary));
            border-radius: 4px;
        }
        
        .rating-bar-count {
            width: 40px;
            text-align: right;
            color: #6c757d;
            font-size: 14px;
        }
        
        .write-review-btn {
            margin-top: 20px;
            background: linear-gradient(to right, var(--primary-light), var(--primary));
            border: none;
            color: white;
            padding: 12px 25px;
            border-radius: 30px;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(111, 66, 193, 0.2);
        }
        
        .write-review-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(111, 66, 193, 0.3);
            background: linear-gradient(to right, var(--primary), var(--primary-dark));
        }
        
        .write-review-btn i {
            margin-right: 8px;
        }
        
        .page-title {
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #dee2e6;
            font-weight: 600;
            color: #333;
        }
        
        /* Filter Styles */
        .filter-tabs {
            display: flex;
            margin-bottom: 20px;
            border-bottom: 1px solid #dee2e6;
            padding-bottom: 10px;
        }
        
        .filter-tab {
            padding: 8px 15px;
            border-radius: 20px;
            margin-right: 10px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 14px;
            font-weight: 500;
        }
        
        .filter-tab.active {
            background-color: var(--primary);
            color: white;
        }
        
        .filter-tab:not(.active):hover {
            background-color: rgba(111, 66, 193, 0.1);
            color: var(--primary);
        }
        
        /* Responsive Adjustments */
        @media (max-width: 768px) {
            body {
                padding-top: 80px;
            }
            
            .main-content {
                padding-top: 15px;
            }
            
            .rating-summary-header {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .rating-summary-score {
                margin-right: 0;
                margin-bottom: 10px;
            }
        }
    </style>
</head>
<body>
<?= $this->include('templates/navbardashboard') ?>
    
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 main-content">
                <?php if(session()->getFlashdata('success')): ?>
                    <div class="alert alert-success">
                        <?= session()->getFlashdata('success') ?>
                    </div>
                <?php endif; ?>
                
                <?php if(session()->getFlashdata('error')): ?>
                    <div class="alert alert-danger">
                        <?= session()->getFlashdata('error') ?>
                    </div>
                <?php endif; ?>
                
                <!-- Reviews Content -->
                <h1 class="page-title">Customer Reviews</h1>
                
                <div class="row">
                    <div class="col-lg-4 mb-4">
                        <div class="card">
                            <div class="card-body">
                                <div class="rating-summary">
                                    <div class="rating-summary-header">
                                        <div class="rating-summary-score">4.8</div>
                                        <div class="rating-summary-stars">
                                            <div class="stars">
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star-half-alt"></i>
                                            </div>
                                            <div class="reviews-count">Based on 1,234 reviews</div>
                                        </div>
                                    </div>
                                    
                                    <div class="rating-bars">
                                        <div class="rating-bar">
                                            <div class="rating-bar-label">
                                                <i class="fas fa-star"></i> 5
                                            </div>
                                            <div class="rating-bar-progress">
                                                <div class="rating-bar-progress-inner" style="width: 80%"></div>
                                            </div>
                                            <div class="rating-bar-count">986</div>
                                        </div>
                                        
                                        <div class="rating-bar">
                                            <div class="rating-bar-label">
                                                <i class="fas fa-star"></i> 4
                                            </div>
                                            <div class="rating-bar-progress">
                                                <div class="rating-bar-progress-inner" style="width: 15%"></div>
                                            </div>
                                            <div class="rating-bar-count">185</div>
                                        </div>
                                        
                                        <div class="rating-bar">
                                            <div class="rating-bar-label">
                                                <i class="fas fa-star"></i> 3
                                            </div>
                                            <div class="rating-bar-progress">
                                                <div class="rating-bar-progress-inner" style="width: 3%"></div>
                                            </div>
                                            <div class="rating-bar-count">37</div>
                                        </div>
                                        
                                        <div class="rating-bar">
                                            <div class="rating-bar-label">
                                                <i class="fas fa-star"></i> 2
                                            </div>
                                            <div class="rating-bar-progress">
                                                <div class="rating-bar-progress-inner" style="width: 1%"></div>
                                            </div>
                                            <div class="rating-bar-count">12</div>
                                        </div>
                                        
                                        <div class="rating-bar">
                                            <div class="rating-bar-label">
                                                <i class="fas fa-star"></i> 1
                                            </div>
                                            <div class="rating-bar-progress">
                                                <div class="rating-bar-progress-inner" style="width: 1%"></div>
                                            </div>
                                            <div class="rating-bar-count">14</div>
                                        </div>
                                    </div>
                                </div>
                                
                                <button class="btn write-review-btn w-100">
                                    <i class="fas fa-pencil-alt"></i> Write a Review
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-8">
                        <div class="filter-tabs">
                            <div class="filter-tab active">All Reviews</div>
                            <div class="filter-tab">Recent</div>
                            <div class="filter-tab">5 Star</div>
                            <div class="filter-tab">Critical</div>
                            <div class="filter-tab">With Photos</div>
                        </div>
                        
                        <!-- Review Cards -->
                        <div class="review-card">
                            <div class="review-header">
                                <div class="review-avatar">JD</div>
                                <div class="review-user">
                                    <h5>John Doe</h5>
                                    <p>Client since 2022</p>
                                </div>
                                <div class="review-rating">
                                    <div class="review-stars">
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                    </div>
                                    <div class="review-date">Jul 15, 2023</div>
                                </div>
                            </div>
                            <div class="review-content">
                                <div class="review-text">
                                    <p>Absolutely amazing service! I've been using the SMM panel for my social media marketing business for 6 months now, and it has completely transformed how I operate. The panel is intuitive, fast, and offers a wide range of services at competitive prices.</p>
                                    <p>Customer support is also exceptional - quick to respond and very helpful. Highly recommend to anyone in the social media marketing industry!</p>
                                </div>
                                <div class="review-photos">
                                    <img src="https://via.placeholder.com/80" alt="Review photo" class="review-photo">
                                    <img src="https://via.placeholder.com/80" alt="Review photo" class="review-photo">
                                </div>
                            </div>
                            <div class="review-footer">
                                <div class="review-actions">
                                    <button><i class="fas fa-thumbs-up"></i> Helpful (24)</button>
                                    <button><i class="fas fa-comment"></i> Comment</button>
                                </div>
                                <div class="review-stats">
                                    <div class="review-stat">
                                        <i class="fas fa-eye"></i> 356 views
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="review-card">
                            <div class="review-header">
                                <div class="review-avatar">SM</div>
                                <div class="review-user">
                                    <h5>Sarah Miller</h5>
                                    <p>Client since 2021</p>
                                </div>
                                <div class="review-rating">
                                    <div class="review-stars">
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                    </div>
                                    <div class="review-date">Jun 22, 2023</div>
                                </div>
                            </div>
                            <div class="review-content">
                                <div class="review-text">
                                    <p>I've been using this panel for over a year now, and I can confidently say it's the best SMM panel in the market. The API integration works flawlessly with my website, and the automated order processing saves me hours of work every day.</p>
                                    <p>The dashboard is clean and easy to navigate, and the child panel feature has allowed me to expand my business by creating reseller accounts for my team members. Great job!</p>
                                </div>
                            </div>
                            <div class="review-footer">
                                <div class="review-actions">
                                    <button><i class="fas fa-thumbs-up"></i> Helpful (18)</button>
                                    <button><i class="fas fa-comment"></i> Comment</button>
                                </div>
                                <div class="review-stats">
                                    <div class="review-stat">
                                        <i class="fas fa-eye"></i> 284 views
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="review-card">
                            <div class="review-header">
                                <div class="review-avatar">RJ</div>
                                <div class="review-user">
                                    <h5>Robert Johnson</h5>
                                    <p>Client since 2023</p>
                                </div>
                                <div class="review-rating">
                                    <div class="review-stars">
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="far fa-star"></i>
                                    </div>
                                    <div class="review-date">Aug 5, 2023</div>
                                </div>
                            </div>
                            <div class="review-content">
                                <div class="review-text">
                                    <p>Great service overall, but there's room for improvement. The panel offers a wide range of services, and the pricing is competitive. However, I've experienced some delays in order processing during peak hours.</p>
                                    <p>The support team is responsive and helpful, which makes up for the occasional delays. I would recommend this panel to others in the industry, but be aware that it might not be perfect during high-traffic periods.</p>
                                </div>
                                <div class="review-photos">
                                    <img src="https://via.placeholder.com/80" alt="Review photo" class="review-photo">
                                </div>
                            </div>
                            <div class="review-footer">
                                <div class="review-actions">
                                    <button><i class="fas fa-thumbs-up"></i> Helpful (12)</button>
                                    <button><i class="fas fa-comment"></i> Comment</button>
                                </div>
                                <div class="review-stats">
                                    <div class="review-stat">
                                        <i class="fas fa-eye"></i> 193 views
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Load More Button -->
                        <div class="text-center mt-4">
                            <button class="btn btn-outline-primary">Load More Reviews</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 