<nav class="navbar navbar-expand-lg navbar-light bg-white fixed-top">
    <div class="container">
        <a class="navbar-brand brand" href="<?= base_url() ?>">
            <img src="<?= base_url('assets/images/logo.png') ?>" alt="Geo Rental Panel"> <!- Yahan logo ka path check kar lein ->
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link active" href="<?= base_url() ?>">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="<?= base_url('#features') ?>">Features</a></li>
                <li class="nav-item"><a class="nav-link" href="<?= base_url('#pricing') ?>">Pricing</a></li>
                <li class="nav-item"><a class="nav-link" href="<?= base_url('#contact') ?>">Contact</a></li>
                <li class="nav-item ms-lg-2">
                    <a class="nav-link btn-3d-green" href="<?= site_url('login') ?>">
                        <i class="fas fa-sign-in-alt me-1"></i>Login
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<style>
    /* 3D Green Login Button */
    .btn-3d-green {
        background: linear-gradient(145deg, #28a745, #20c997) !important;
        color: white !important;
        padding: 12px 24px !important;
        border-radius: 25px !important;
        text-decoration: none !important;
        font-weight: 600 !important;
        font-size: 14px !important;
        text-transform: uppercase !important;
        letter-spacing: 0.5px !important;
        box-shadow: 
            0 8px 15px rgba(40, 167, 69, 0.3),
            0 4px 6px rgba(0, 0, 0, 0.1),
            inset 0 1px 0 rgba(255, 255, 255, 0.2) !important;
        border: 2px solid #1e7e34 !important;
        position: relative !important;
        overflow: hidden !important;
        transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275) !important;
        transform: translateY(0) !important;
    }
    
    /* 3D Green Effect for Active Navigation Items */
    .nav-link.active {
        background: linear-gradient(145deg, #28a745, #20c997) !important;
        color: white !important;
        padding: 8px 16px !important;
        border-radius: 20px !important;
        text-decoration: none !important;
        font-weight: 600 !important;
        box-shadow: 
            0 6px 12px rgba(40, 167, 69, 0.3),
            0 3px 6px rgba(0, 0, 0, 0.1),
            inset 0 1px 0 rgba(255, 255, 255, 0.2) !important;
        border: 1px solid #1e7e34 !important;
        position: relative !important;
        overflow: hidden !important;
        transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275) !important;
        transform: translateY(0) !important;
        margin: 0 5px !important;
    }
    
    .nav-link.active::before {
        content: '' !important;
        position: absolute !important;
        top: 0 !important;
        left: -100% !important;
        width: 100% !important;
        height: 100% !important;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent) !important;
        transition: left 0.5s !important;
    }
    
    .nav-link.active:hover {
        background: linear-gradient(145deg, #20c997, #17a2b8) !important;
        color: white !important;
        transform: translateY(-2px) !important;
        box-shadow: 
            0 8px 16px rgba(40, 167, 69, 0.4),
            0 4px 8px rgba(0, 0, 0, 0.15),
            inset 0 1px 0 rgba(255, 255, 255, 0.3) !important;
        border-color: #138496 !important;
    }
    
    .nav-link.active:hover::before {
        left: 100% !important;
    }
    
    /* 3D Hover Effect for Non-Active Navigation Items */
    .nav-link:not(.active):not(.btn-3d-green) {
        transition: all 0.3s ease !important;
        border-radius: 15px !important;
        padding: 8px 16px !important;
        margin: 0 5px !important;
        position: relative !important;
    }
    
    .nav-link:not(.active):not(.btn-3d-green):hover {
        background: linear-gradient(145deg, rgba(40, 167, 69, 0.1), rgba(32, 201, 151, 0.1)) !important;
        color: #28a745 !important;
        transform: translateY(-1px) !important;
        box-shadow: 
            0 4px 8px rgba(40, 167, 69, 0.2),
            0 2px 4px rgba(0, 0, 0, 0.1) !important;
        border: 1px solid rgba(40, 167, 69, 0.3) !important;
    }
    
    .btn-3d-green::before {
        content: '' !important;
        position: absolute !important;
        top: 0 !important;
        left: -100% !important;
        width: 100% !important;
        height: 100% !important;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent) !important;
        transition: left 0.5s !important;
    }
    
    .btn-3d-green:hover {
        background: linear-gradient(145deg, #20c997, #17a2b8) !important;
        color: white !important;
        transform: translateY(-3px) !important;
        box-shadow: 
            0 12px 25px rgba(40, 167, 69, 0.4),
            0 6px 12px rgba(0, 0, 0, 0.15),
            inset 0 1px 0 rgba(255, 255, 255, 0.3) !important;
        border-color: #138496 !important;
    }
    
    .btn-3d-green:hover::before {
        left: 100% !important;
    }
    
    .btn-3d-green:active {
        transform: translateY(-1px) !important;
        box-shadow: 
            0 4px 8px rgba(40, 167, 69, 0.3),
            0 2px 4px rgba(0, 0, 0, 0.1),
            inset 0 1px 0 rgba(255, 255, 255, 0.2) !important;
    }
    
    .btn-3d-green i {
        font-size: 12px !important;
        margin-right: 6px !important;
    }
    
    /* Responsive adjustments */
    @media (max-width: 991px) {
        .btn-3d-green {
            margin-top: 10px !important;
            display: inline-block !important;
            width: auto !important;
        }
        
        .nav-link.active,
        .nav-link:not(.active):not(.btn-3d-green) {
            margin: 5px 0 !important;
        }
    }
    
    @media (max-width: 767px) {
        .btn-3d-green {
            padding: 10px 20px !important;
            font-size: 13px !important;
            border-radius: 20px !important;
        }
        
        .nav-link.active {
            padding: 6px 12px !important;
            font-size: 14px !important;
            border-radius: 15px !important;
        }
    }
    
    /* Mobile Styles */
    @media (max-width: 767px) {
        .navbar-brand.brand {
            max-width: 200px;
            width: 200px;
            height: 53px;
            padding-bottom: 0px;
            margin-right: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            line-height: 1;
        }
        .navbar-brand.brand img {
            max-width: 100%;
            max-height: 100%;
            width: 200px;
            height: 53px;
            object-fit: contain;
        }
        .navbar.fixed-top {
            position: fixed !important;
            top: 0 !important;
            left: 0;
            right: 0;
            z-index: 1030;
            transform: translateZ(0);
            -webkit-transform: translateZ(0);
        }
    }
</style>

<style>
    /* Mobile Styles */
    @media (max-width: 767px) {
        .navbar-brand.brand {
            max-width: 200px;
            width: 200px;
            height: 53px;
            padding-bottom: 0px;
            margin-right: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            line-height: 1;
        }
        .navbar-brand.brand img {
            max-width: 100%;
            max-height: 100%;
            width: 200px;
            height: 53px;
            object-fit: contain;
        }
        .navbar.fixed-top {
            position: fixed !important;
            top: 0 !important;
            left: 0;
            right: 0;
            z-index: 1030;
            transform: translateZ(0);
            -webkit-transform: translateZ(0);
            will-change: transform;
            transition: transform 0.3s ease-out;
        }
        /* Adjust body padding if content is hidden by fixed navbar on mobile */
        body {
            padding-top: 70px; /* Example: Adjust this based on your navbar's actual height on mobile */
        }
        /* Prevent navbar from moving during scroll */
        html {
            overflow-x: hidden;
        }
    }

    /* Desktop Styles */
    .navbar-brand.brand {
        padding-bottom: 5px;
        margin-right: 15px;
        display: flex;
        align-items: center;
        line-height: 1;
    }

    .navbar-brand.brand img {
        max-width: 250px;
        height: auto;
        max-height: 60px;
        object-fit: contain;
    }

    .navbar {
        box-shadow: 0 2px 8px rgba(0,0,0,0.03);
    }

    
</style>

<script>
// Agar aapke paas home page ke bahar #features, #pricing, #contact links hain,
// toh woh shayad seedhe kaam na karein. Uske liye aapko JavaScript se handle karna pad sakta hai
// ya phir full URLs (e.g., base_url('home#features')) istemal karne honge.
// Filhaal, maine links ko base_url() ke sath #section_id format mein rakha hai,
// jo same page par scroll karega agar woh section maujood hai.

// Example: Smooth scroll for same-page links (optional)
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        let href = this.getAttribute('href');
        // Check if it's a link to an element on the current page
        if (href.startsWith('#') && href.length > 1 && document.querySelector(href)) {
            e.preventDefault();
            document.querySelector(href).scrollIntoView({
                behavior: 'smooth'
            });
        }
    });
});

// Add this script to prevent navbar jump during scroll
window.addEventListener('scroll', function() {
    if (window.innerWidth <= 767) { // Mobile view only
        document.querySelector('.navbar.fixed-top').style.transform = 'translateZ(0)';
    }
});
</script>
