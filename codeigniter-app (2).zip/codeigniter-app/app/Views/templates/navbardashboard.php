<nav class="navbar navbar-expand-lg navbar-light bg-white fixed-top shadow-sm">
    <div class="container">
        <!-- Brand Logo (Left) -->
        <a class="navbar-brand brand" href="<?= base_url() ?>">
            <img src="<?= base_url('assets/images/logo.png') ?>" alt="Geo Rental Panel"> 
        </a>
        
        <!-- Currency Toggle (Center) - Visible only in desktop view -->
        <div class="d-none d-lg-flex justify-content-center currency-container">
            <div class="nav-item dropdown">
                <a class="nav-link dropdown-toggle currency-toggle" href="#" id="currencyDropdownDesktop" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="fas fa-money-bill-wave me-1"></i> <span id="currentCurrencyDesktop">USD</span>
                </a>
                <ul class="dropdown-menu" aria-labelledby="currencyDropdownDesktop">
                    <li><a class="dropdown-item" href="#" onclick="changeCurrency('USD')">USD</a></li>
                    <li><a class="dropdown-item" href="#" onclick="changeCurrency('PKR')">PKR</a></li>
                    <li><a class="dropdown-item" href="#" onclick="changeCurrency('INR')">INR</a></li>
                </ul>
            </div>
        </div>
        
        <!-- Mobile Toggle Button (Right) -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <!-- Navbar Collapse -->
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <!-- Currency Toggle - Visible only in mobile view and at the top -->
                <li class="nav-item dropdown d-lg-none mb-3">
                    <a class="nav-link dropdown-toggle currency-toggle" href="#" id="currencyDropdownMobile" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-money-bill-wave me-1"></i> <span id="currentCurrencyMobile">USD</span>
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="currencyDropdownMobile">
                        <li><a class="dropdown-item" href="#" onclick="changeCurrency('USD')">USD</a></li>
                        <li><a class="dropdown-item" href="#" onclick="changeCurrency('PKR')">PKR</a></li>
                        <li><a class="dropdown-item" href="#" onclick="changeCurrency('INR')">INR</a></li>
                    </ul>
                </li>
                
                <!-- Navigation Menu Items - Only visible on mobile -->
                <li class="nav-item d-lg-none">
                    <a class="nav-link" href="<?= site_url('affiliate') ?>" data-page="invite"><i class="fas fa-user-plus me-1"></i> Invite & Earn</a>
                </li>
                <li class="nav-item d-lg-none">
                    <a class="nav-link" href="<?= site_url('dashboard') ?>" data-page="dashboard"><i class="fas fa-plus-circle me-1"></i> Set-Up New Panel</a>
                </li>
                <li class="nav-item d-lg-none">
                    <a class="nav-link" href="<?= site_url('panels') ?>" data-page="panels"><i class="fas fa-th me-1"></i> My Panels</a>
                </li>
                <li class="nav-item d-lg-none">
                    <a class="nav-link" href="<?= site_url('child-panels') ?>" data-page="child-panels"><i class="fas fa-users me-1"></i> Child Panels</a>
                </li>
                <li class="nav-item d-lg-none">
                    <a class="nav-link" href="<?= site_url('add-fund') ?>" data-page="deposit"><i class="fas fa-money-bill-wave me-1"></i> Add Fund</a>
                </li>
                <li class="nav-item d-lg-none">
                    <a class="nav-link" href="<?= site_url('help') ?>" data-page="help"><i class="fas fa-question-circle me-1"></i> Help</a>
                </li>
                <li class="nav-item d-lg-none">
                    <a class="nav-link" href="<?= site_url('reviews') ?>" data-page="reviews"><i class="fas fa-star me-1"></i> Reviews</a>
                </li>
                <li class="nav-item d-lg-none">
                    <a class="nav-link" href="<?= site_url('account') ?>" data-page="account"><i class="fas fa-user me-1"></i> Account</a>
                </li>
                <li class="nav-item d-lg-none">
                    <a class="nav-link" href="<?= site_url('logout') ?>" data-page="logout"><i class="fas fa-sign-out-alt me-1"></i> Logout</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Currency Toggle Styling اور JavaScript -->
<style>
    /* Currency Container Positioning */
    .currency-container {
        position: absolute;
        left: 50%;
        transform: translateX(-50%);
    }

    /* Currency Toggle Styling - Enhanced */
    .currency-toggle {
        background: linear-gradient(145deg, #f8f9fa, #e9ecef);
        border-radius: 20px;
        padding: 8px 16px !important;
        color: #28a745 !important;
        font-weight: 600;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        border: 1px solid rgba(40, 167, 69, 0.2);
        transition: all 0.3s ease;
        text-align: center;
    }
    
    .currency-toggle:hover {
        background: linear-gradient(145deg, #e9ecef, #dee2e6);
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.15);
    }
    
    .currency-toggle i {
        color: #28a745;
    }
    
    /* Currency Display Styling */
    .currency-display {
        display: flex;
        flex-direction: column;
        align-items: center;
        padding: 8px 16px;
        background: linear-gradient(145deg, #f8f9fa, #e9ecef);
        border-radius: 12px;
        border: 1px solid #dee2e6;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    
    .currency-label {
        font-size: 10px;
        color: #6c757d;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-bottom: 2px;
    }
    
    .currency-amount {
        font-size: 16px;
        font-weight: 700;
        color: #dc3545; /* Red color for available fund */
        text-shadow: 0 1px 2px rgba(0,0,0,0.1);
    }
    
    /* Responsive adjustments */
    @media (max-width: 991px) {
        .currency-display {
            margin: 10px 0;
            flex-direction: row;
            gap: 10px;
        }
        
        .currency-label {
            margin-bottom: 0;
        }
    }
    
    /* Logo Styling */
    .navbar-brand.brand {
        padding-bottom: 5px;
        margin-right: 15px;
        display: flex;
        align-items: center;
        justify-content: center;
        overflow: hidden;
        line-height: 1;
    }
    
    .navbar-brand.brand img {
        max-width: 100%;
        max-height: 100%;
        width: 200px;
        object-fit: contain;
    }
    
    /* Desktop Styles */
    @media (min-width: 992px) {
        .navbar-brand.brand {
            padding-bottom: 5px;
            margin-right: 15px;
        }

        .navbar-brand.brand img {
            max-width: 250px;
            height: auto;
            max-height: 60px;
        }
    }
    
    /* Mobile Styles */
    @media (max-width: 767px) {
        .navbar-brand.brand {
            max-width: 200px;
            width: 200px;
            height: 53px;
        }
        
        .navbar-brand.brand img {
            width: 200px;
            height: 53px;
        }
    }
    
    /* Dropdown Menu Styling */
    .dropdown-menu {
        background: white !important;
        border: 1px solid rgba(40, 167, 69, 0.2) !important;
        border-radius: 15px !important;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1) !important;
        padding: 10px 0 !important;
        margin-top: 10px !important;
    }
    
    .dropdown-item {
        padding: 10px 20px !important;
        transition: all 0.3s ease !important;
        border-radius: 10px !important;
        margin: 2px 10px !important;
    }
    
    .dropdown-item:hover {
        background: linear-gradient(145deg, rgba(40, 167, 69, 0.1), rgba(32, 201, 151, 0.1)) !important;
        color: #28a745 !important;
        transform: translateX(5px) !important;
    }
    
    /* Responsive adjustments */
    @media (max-width: 991px) {
        .dropdown-menu {
            position: static !important;
            float: none !important;
            width: auto !important;
            margin-top: 0 !important;
            background-color: transparent !important;
            border: 0 !important;
            box-shadow: none !important;
        }
    }
    
    /* Mobile Styles */
    @media (max-width: 767px) {
        .navbar-brand.brand {
            max-width: 200px;
            width: 200px;
            height: 53px;
            padding-bottom: 0px;
            margin-right: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            line-height: 1;
        }
        .navbar-brand.brand img {
            max-width: 100%;
            max-height: 100%;
            width: 200px;
            height: 53px;
            object-fit: contain;
        }
        .navbar.fixed-top {
            position: fixed !important;
            top: 0 !important;
            left: 0;
            right: 0;
            z-index: 1030;
            transform: translateZ(0);
            -webkit-transform: translateZ(0);
            will-change: transform;
            transition: transform 0.3s ease-out;
        }
        /* Adjust body padding if content is hidden by fixed navbar on mobile */
        body {
            padding-top: 70px; /* Example: Adjust this based on your navbar's actual height on mobile */
        }
        /* Prevent navbar from moving during scroll */
        html {
            overflow-x: hidden;
        }
    }

    /* Desktop Styles */
    .navbar-brand.brand {
        padding-bottom: 5px;
        margin-right: 15px;
        display: flex;
        align-items: center;
        line-height: 1;
    }

    .navbar-brand.brand img {
        max-width: 250px;
        height: auto;
        max-height: 60px;
        object-fit: contain;
    }

    .navbar {
        box-shadow: 0 2px 8px rgba(0,0,0,0.03);
    }

    /* Mobile styling for currency toggle */
    @media (max-width: 991px) {
        .navbar-nav .nav-item.dropdown.mb-3 .currency-toggle {
            text-align: center;
            margin-bottom: 10px;
            border: 1px solid rgba(40, 167, 69, 0.2);
            background: linear-gradient(145deg, #f8f9fa, #e9ecef);
        }
        
        .navbar-nav .nav-item.dropdown.mb-3 {
            border-bottom: 1px solid rgba(0,0,0,0.1);
            padding-bottom: 15px;
            margin-bottom: 15px;
        }
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Get current page from URL
        const currentPath = window.location.pathname;
        let currentPage = '';
        
        // Determine current page based on path
        if (currentPath.includes('/dashboard')) {
            currentPage = 'dashboard';
        } else if (currentPath.includes('/panels')) {
            currentPage = 'panels';
        } else if (currentPath.includes('/child-panels')) {
            currentPage = 'child-panels';
        } else if (currentPath.includes('/add-fund')) {
            currentPage = 'deposit';
        } else if (currentPath.includes('/help')) {
            currentPage = 'help';
        } else if (currentPath.includes('/reviews')) {
            currentPage = 'reviews';
        } else if (currentPath.includes('/account')) {
            currentPage = 'account';
        } else if (currentPath.includes('/affiliate')) {
            currentPage = 'invite';
        }
        
        // Set active class for desktop menu
        const desktopLinks = document.querySelectorAll('.desktop-nav .nav-link');
        desktopLinks.forEach(link => {
            const dataPage = link.getAttribute('data-page');
            if (dataPage === currentPage) {
                link.classList.add('active');
            } else {
                link.classList.remove('active');
            }
        });
        
        // Set active class for mobile menu
        const mobileLinks = document.querySelectorAll('.offcanvas-body .nav-link');
        mobileLinks.forEach(link => {
            const dataPage = link.getAttribute('data-page');
            if (dataPage === currentPage) {
                link.classList.add('active');
            } else {
                link.classList.remove('active');
            }
        });
    });

    // Handle currency toggle
    const currencyButtons = document.querySelectorAll('.currency-toggle button');
    currencyButtons.forEach(button => {
        button.addEventListener('click', function() {
            currencyButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
        });
    });
</script>

<style>
    /* Currency Display Styling */
    .currency-display {
        display: flex;
        flex-direction: column;
        align-items: center;
        padding: 8px 16px;
        background: linear-gradient(145deg, #f8f9fa, #e9ecef);
        border-radius: 12px;
        border: 1px solid #dee2e6;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    
    .currency-label {
        font-size: 10px;
        color: #6c757d;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-bottom: 2px;
    }
    
    .currency-amount {
        font-size: 16px;
        font-weight: 700;
        color: #dc3545; /* Red color for available fund */
        text-shadow: 0 1px 2px rgba(0,0,0,0.1);
    }
    
    /* Responsive adjustments */
    @media (max-width: 991px) {
        .currency-display {
            margin: 10px 0;
            flex-direction: row;
            gap: 10px;
        }
        
        .currency-label {
            margin-bottom: 0;
        }
    }
    
    /* 3D Green Account Button */
    .btn-3d-green {
        background: linear-gradient(145deg, #28a745, #20c997) !important;
        color: white !important;
        padding: 12px 24px !important;
        border-radius: 25px !important;
        text-decoration: none !important;
        font-weight: 600 !important;
        font-size: 14px !important;
        text-transform: uppercase !important;
        letter-spacing: 0.5px !important;
        box-shadow: 
            0 8px 15px rgba(40, 167, 69, 0.3),
            0 4px 6px rgba(0, 0, 0, 0.1),
            inset 0 1px 0 rgba(255, 255, 255, 0.2) !important;
        border: 2px solid #1e7e34 !important;
        position: relative !important;
        overflow: hidden !important;
        transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275) !important;
        transform: translateY(0) !important;
    }
    
    /* 3D Green Effect for Active Navigation Items */
    .nav-link.active {
        background: linear-gradient(145deg, #28a745, #20c997) !important;
        color: white !important;
        padding: 8px 16px !important;
        border-radius: 20px !important;
        text-decoration: none !important;
        font-weight: 600 !important;
        box-shadow: 
            0 6px 12px rgba(40, 167, 69, 0.3),
            0 3px 6px rgba(0, 0, 0, 0.1),
            inset 0 1px 0 rgba(255, 255, 255, 0.2) !important;
        border: 1px solid #1e7e34 !important;
        position: relative !important;
        overflow: hidden !important;
        transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275) !important;
        transform: translateY(0) !important;
        margin: 0 5px !important;
    }
    
    .nav-link.active::before {
        content: '' !important;
        position: absolute !important;
        top: 0 !important;
        left: -100% !important;
        width: 100% !important;
        height: 100% !important;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent) !important;
        transition: left 0.5s !important;
    }
    
    .nav-link.active:hover {
        background: linear-gradient(145deg, #20c997, #17a2b8) !important;
        color: white !important;
        transform: translateY(-2px) !important;
        box-shadow: 
            0 8px 16px rgba(40, 167, 69, 0.4),
            0 4px 8px rgba(0, 0, 0, 0.15),
            inset 0 1px 0 rgba(255, 255, 255, 0.3) !important;
        border-color: #138496 !important;
    }
    
    .nav-link.active:hover::before {
        left: 100% !important;
    }
    
    /* 3D Hover Effect for Non-Active Navigation Items */
    .nav-link:not(.active):not(.btn-3d-green) {
        transition: all 0.3s ease !important;
        border-radius: 15px !important;
        padding: 8px 16px !important;
        margin: 0 5px !important;
        position: relative !important;
    }
    
    .nav-link:not(.active):not(.btn-3d-green):hover {
        background: linear-gradient(145deg, rgba(40, 167, 69, 0.1), rgba(32, 201, 151, 0.1)) !important;
        color: #28a745 !important;
        transform: translateY(-1px) !important;
        box-shadow: 
            0 4px 8px rgba(40, 167, 69, 0.2),
            0 2px 4px rgba(0, 0, 0, 0.1) !important;
        border: 1px solid rgba(40, 167, 69, 0.3) !important;
    }
    
    .btn-3d-green::before {
        content: '' !important;
        position: absolute !important;
        top: 0 !important;
        left: -100% !important;
        width: 100% !important;
        height: 100% !important;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent) !important;
        transition: left 0.5s !important;
    }
    
    .btn-3d-green:hover {
        background: linear-gradient(145deg, #20c997, #17a2b8) !important;
        color: white !important;
        transform: translateY(-3px) !important;
        box-shadow: 
            0 12px 25px rgba(40, 167, 69, 0.4),
            0 6px 12px rgba(0, 0, 0, 0.15),
            inset 0 1px 0 rgba(255, 255, 255, 0.3) !important;
        border-color: #138496 !important;
    }
    
    .btn-3d-green:hover::before {
        left: 100% !important;
    }
    
    .btn-3d-green:active {
        transform: translateY(-1px) !important;
        box-shadow: 
            0 4px 8px rgba(40, 167, 69, 0.3),
            0 2px 4px rgba(0, 0, 0, 0.1),
            inset 0 1px 0 rgba(255, 255, 255, 0.2) !important;
    }
    
    .btn-3d-green i {
        font-size: 12px !important;
        margin-right: 6px !important;
    }
    
    /* Dropdown Menu Styling */
    .dropdown-menu {
        background: white !important;
        border: 1px solid rgba(40, 167, 69, 0.2) !important;
        border-radius: 15px !important;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1) !important;
        padding: 10px 0 !important;
        margin-top: 10px !important;
    }
    
    .dropdown-item {
        padding: 10px 20px !important;
        transition: all 0.3s ease !important;
        border-radius: 10px !important;
        margin: 2px 10px !important;
    }
    
    .dropdown-item:hover {
        background: linear-gradient(145deg, rgba(40, 167, 69, 0.1), rgba(32, 201, 151, 0.1)) !important;
        color: #28a745 !important;
        transform: translateX(5px) !important;
    }
    
    .dropdown-item.text-danger:hover {
        background: linear-gradient(145deg, rgba(220, 53, 69, 0.1), rgba(255, 0, 0, 0.1)) !important;
        color: #dc3545 !important;
    }
    
    .dropdown-divider {
        border-color: rgba(40, 167, 69, 0.2) !important;
        margin: 8px 0 !important;
    }
    
    /* Responsive adjustments */
    @media (max-width: 991px) {
        .btn-3d-green {
            margin-top: 10px !important;
            display: inline-block !important;
            width: auto !important;
        }
        
        .nav-link.active,
        .nav-link:not(.active):not(.btn-3d-green) {
            margin: 5px 0 !important;
        }
        
        .dropdown-menu {
            position: static !important;
            float: none !important;
            width: auto !important;
            margin-top: 0 !important;
            background-color: transparent !important;
            border: 0 !important;
            box-shadow: none !important;
        }
    }
    
    @media (max-width: 767px) {
        .btn-3d-green {
            padding: 10px 20px !important;
            font-size: 13px !important;
            border-radius: 20px !important;
        }
        
        .nav-link.active {
            padding: 6px 12px !important;
            font-size: 14px !important;
            border-radius: 15px !important;
        }
    }
    
    /* Mobile Styles */
    @media (max-width: 767px) {
        .navbar-brand.brand {
            max-width: 200px;
            width: 200px;
            height: 53px;
            padding-bottom: 0px;
            margin-right: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            line-height: 1;
        }
        .navbar-brand.brand img {
            max-width: 100%;
            max-height: 100%;
            width: 200px;
            height: 53px;
            object-fit: contain;
        }
        .navbar.fixed-top {
            position: fixed !important;
            top: 0 !important;
            left: 0;
            right: 0;
            z-index: 1030;
            transform: translateZ(0);
            -webkit-transform: translateZ(0);
            will-change: transform;
            transition: transform 0.3s ease-out;
        }
        /* Adjust body padding if content is hidden by fixed navbar on mobile */
        body {
            padding-top: 70px; /* Example: Adjust this based on your navbar's actual height on mobile */
        }
        /* Prevent navbar from moving during scroll */
        html {
            overflow-x: hidden;
        }
    }

    /* Desktop Styles */
    .navbar-brand.brand {
        padding-bottom: 5px;
        margin-right: 15px;
        display: flex;
        align-items: center;
        line-height: 1;
    }

    .navbar-brand.brand img {
        max-width: 250px;
        height: auto;
        max-height: 60px;
        object-fit: contain;
    }

    .navbar {
        box-shadow: 0 2px 8px rgba(0,0,0,0.03);
    }
</style>

<style>
    /* Mobile Navigation Improvements */
    @media (max-width: 991px) {
        /* Better spacing for navigation items on mobile */
        .navbar-nav .nav-item {
            margin-bottom: 8px;
            border-bottom: 1px solid rgba(0,0,0,0.05);
            padding-bottom: 8px;
        }
        
        .navbar-nav .nav-item:last-child {
            border-bottom: none;
        }
        
        /* Make navbar links take full width on mobile */
        .navbar-nav .nav-link {
            display: block;
            width: 100%;
            padding: 10px 15px !important;
        }
        
        .navbar-nav .nav-link i {
            width: 20px;
            margin-right: 8px;
            text-align: center;
        }
        
        /* Show dropdown items properly */
        .navbar-nav .dropdown-menu {
            padding-left: 15px;
            margin-top: 5px !important;
        }
        
        /* Add some visual separation between sections */
        .navbar-nav .currency-toggle {
            margin-top: 10px;
            border-top: 1px solid rgba(0,0,0,0.1);
            padding-top: 15px !important;
        }
        
        /* Ensure menu appears below the navbar */
        #navbarNav {
            margin-top: 10px;
            background-color: white;
            border-radius: 10px;
            padding: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
    }
</style>

<script src="<?= base_url('assets/js/dashboard.js') ?>"></script>

<!-- Desktop Navigation Menu - Now directly included in the navbar template -->
<div class="desktop-nav-container d-none d-lg-block">
    <div class="container">
        <div class="desktop-nav">
            <ul class="nav nav-pills">
                <li class="nav-item">
                    <a class="nav-link" href="<?= site_url('affiliate') ?>" data-page="invite"><i class="fas fa-user-plus me-1"></i> Invite & Earn</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= site_url('dashboard') ?>" data-page="dashboard"><i class="fas fa-plus-circle me-1"></i> Set-Up New Panel</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= site_url('panels') ?>" data-page="panels"><i class="fas fa-th me-1"></i> My Panels</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= site_url('child-panels') ?>" data-page="child-panels"><i class="fas fa-users me-1"></i> Child Panels</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= site_url('add-fund') ?>" data-page="deposit"><i class="fas fa-money-bill-wave me-1"></i> Add Fund</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= site_url('help') ?>" data-page="help"><i class="fas fa-question-circle me-1"></i> Help</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= site_url('reviews') ?>" data-page="reviews"><i class="fas fa-star me-1"></i> Reviews</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= site_url('account') ?>" data-page="account"><i class="fas fa-user me-1"></i> Account</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= site_url('logout') ?>" data-page="logout"><i class="fas fa-sign-out-alt me-1"></i> Logout</a>
                </li>
            </ul>
        </div>
    </div>
</div>

<style>
    /* Desktop Navigation Styling */
    .desktop-nav-container {
        background-color: #f8f9fa;
        border-bottom: 1px solid rgba(0,0,0,0.1);
        padding: 10px 0;
        box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        margin-bottom: 20px;
        position: sticky;
        top: 70px;
        z-index: 1020;
    }
    
    .desktop-nav {
        display: flex;
        justify-content: center;
    }
    
    .desktop-nav .nav-pills {
        display: flex;
        flex-wrap: nowrap;
        overflow-x: auto;
        padding-bottom: 5px;
        -ms-overflow-style: none; /* IE and Edge */
        scrollbar-width: none; /* Firefox */
    }
    
    .desktop-nav .nav-pills::-webkit-scrollbar {
        display: none; /* Chrome, Safari, Opera */
    }
    
    .desktop-nav .nav-item {
        margin: 0 2px !important;
        white-space: nowrap;
    }
    
    .desktop-nav .nav-link {
        padding: 8px 15px !important;
        border-radius: 20px !important;
        font-size: 14px !important;
        font-weight: 500 !important;
        color: #495057 !important;
        transition: all 0.3s ease !important;
    }
    
    .desktop-nav .nav-link:hover {
        background-color: rgba(111, 66, 193, 0.1) !important;
        color: var(--primary) !important;
        transform: translateY(-2px) !important;
    }
    
    .desktop-nav .nav-link.active {
        background: linear-gradient(145deg, var(--primary), var(--primary-dark)) !important;
        color: white !important;
        box-shadow: 0 4px 10px rgba(111, 66, 193, 0.25) !important;
    }
    
    .desktop-nav .nav-link i {
        margin-right: 6px !important;
    }
    
    @media (min-width: 992px) and (max-width: 1199px) {
        .desktop-nav .nav-link {
            padding: 8px 12px !important;
            font-size: 13px !important;
        }
    }
    
    @media (min-width: 1200px) {
        .desktop-nav .nav-item {
            margin: 0 5px !important;
        }
    }
</style>
