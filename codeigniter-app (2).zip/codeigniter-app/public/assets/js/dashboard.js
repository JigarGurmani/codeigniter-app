/**
 * Dashboard main JavaScript file
 */

document.addEventListener('DOMContentLoaded', function() {
    // Get current page from URL
    const currentPath = window.location.pathname;
    let currentPage = '';
    
    // Determine current page based on path
    if (currentPath.includes('/dashboard')) {
        currentPage = 'dashboard';
    } else if (currentPath.includes('/panels')) {
        currentPage = 'panels';
    } else if (currentPath.includes('/child-panels')) {
        currentPage = 'child-panels';
    } else if (currentPath.includes('/add-fund')) {
        currentPage = 'deposit';
    } else if (currentPath.includes('/help')) {
        currentPage = 'help';
    } else if (currentPath.includes('/reviews')) {
        currentPage = 'reviews';
    } else if (currentPath.includes('/account')) {
        currentPage = 'account';
    } else if (currentPath.includes('/affiliate')) {
        currentPage = 'invite';
    }
    
    // Set active class for desktop menu with a delay to ensure DOM is fully loaded
    setTimeout(() => {
        const desktopLinks = document.querySelectorAll('.desktop-nav .nav-link');
        if (desktopLinks.length > 0) {
            desktopLinks.forEach(link => {
                const dataPage = link.getAttribute('data-page');
                if (dataPage === currentPage) {
                    link.classList.add('active');
                    // Scroll the active item into view if it's off-screen
                    if (link.parentElement && link.parentElement.parentElement) {
                        const navPills = link.parentElement.parentElement;
                        const linkRect = link.getBoundingClientRect();
                        const navRect = navPills.getBoundingClientRect();
                        
                        // Check if the link is out of view
                        if (linkRect.left < navRect.left || linkRect.right > navRect.right) {
                            link.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
                        }
                    }
                } else {
                    link.classList.remove('active');
                }
            });
        }
        
        // Also set active class for mobile menu
        const mobileLinks = document.querySelectorAll('.navbar-nav .nav-link');
        mobileLinks.forEach(link => {
            const dataPage = link.getAttribute('data-page');
            if (dataPage === currentPage) {
                link.classList.add('active');
            } else {
                link.classList.remove('active');
            }
        });
    }, 100);

    // Add event listeners to nav links to provide immediate visual feedback
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', function() {
            // Add a pulse animation class when clicked
            this.classList.add('nav-link-pulse');
            setTimeout(() => {
                this.classList.remove('nav-link-pulse');
            }, 500);
        });
    });

    // Handle currency toggle
    const currencyButtons = document.querySelectorAll('.currency-toggle button');
    if (currencyButtons.length > 0) {
        currencyButtons.forEach(button => {
            button.addEventListener('click', function() {
                currencyButtons.forEach(btn => btn.classList.remove('active'));
                this.classList.add('active');
            });
        });
    }

    // Dashboard smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            let href = this.getAttribute('href');
            // Check if it's a link to an element on the current page
            if (href.startsWith('#') && href.length > 1 && document.querySelector(href)) {
                e.preventDefault();
                document.querySelector(href).scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });

    // Copy functionality for referral links
    const referralLinkElement = document.getElementById('referralLink');
    if (referralLinkElement) {
        const copyButton = referralLinkElement.nextElementSibling;
        if (copyButton) {
            copyButton.addEventListener('click', function() {
                referralLinkElement.select();
                document.execCommand('copy');
                
                // Show feedback
                const originalText = this.innerHTML;
                this.innerHTML = '<i class="fas fa-check me-1"></i> Copied!';
                
                setTimeout(() => {
                    this.innerHTML = originalText;
                }, 2000);
            });
        }
    }

    // Share buttons functionality
    document.querySelectorAll('.share-button').forEach(button => {
        button.addEventListener('click', function() {
            const referralLink = document.getElementById('referralLink')?.value || '';
            const shareText = 'Check out this amazing SMM panel service:';
            let shareUrl = '';
            
            if (this.classList.contains('share-facebook')) {
                shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(referralLink)}`;
            } else if (this.classList.contains('share-twitter')) {
                shareUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(referralLink)}`;
            } else if (this.classList.contains('share-linkedin')) {
                shareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(referralLink)}`;
            } else if (this.classList.contains('share-whatsapp')) {
                shareUrl = `https://wa.me/?text=${encodeURIComponent(shareText + ' ' + referralLink)}`;
            } else if (this.classList.contains('share-telegram')) {
                shareUrl = `https://t.me/share/url?url=${encodeURIComponent(referralLink)}&text=${encodeURIComponent(shareText)}`;
            }
            
            if (shareUrl) {
                window.open(shareUrl, '_blank', 'width=600,height=400');
            }
        });
    });

    // FAQ Accordion Functionality
    document.querySelectorAll('.faq-card .card-header').forEach(header => {
        header.addEventListener('click', function() {
            const body = this.nextElementSibling;
            
            if (body.style.display === 'none' || body.style.display === '') {
                document.querySelectorAll('.faq-card .card-body').forEach(item => {
                    item.style.display = 'none';
                });
                document.querySelectorAll('.faq-card .card-header').forEach(item => {
                    item.classList.remove('active');
                });
                
                body.style.display = 'block';
                this.classList.add('active');
            } else {
                body.style.display = 'none';
                this.classList.remove('active');
            }
        });
    });
    
    // Hide all FAQ answers initially
    document.querySelectorAll('.faq-card .card-body').forEach(body => {
        body.style.display = 'none';
    });
    
    // Filter tabs functionality
    document.querySelectorAll('.filter-tab').forEach(tab => {
        tab.addEventListener('click', function() {
            // Remove active class from all tabs
            document.querySelectorAll('.filter-tab').forEach(t => {
                t.classList.remove('active');
            });
            
            // Add active class to clicked tab
            this.classList.add('active');
            
            // Here you would normally load filtered reviews
            // For this demo, we'll just show a console message
            console.log('Filter selected:', this.textContent.trim());
        });
    });
    
    // Review photo click handler (for future lightbox functionality)
    document.querySelectorAll('.review-photo').forEach(photo => {
        photo.addEventListener('click', function() {
            console.log('Photo clicked:', this.src);
            // Here you would normally open a lightbox or modal
        });
    });

    // Add shadow to desktop nav on scroll
    window.addEventListener('scroll', function() {
        const desktopNav = document.querySelector('.desktop-nav-container');
        if (desktopNav) {
            if (window.scrollY > 70) {
                desktopNav.style.boxShadow = '0 4px 15px rgba(0,0,0,0.1)';
            } else {
                desktopNav.style.boxShadow = '0 2px 10px rgba(0,0,0,0.05)';
            }
        }
    });

    // Add CSS for pulse animation
    const style = document.createElement('style');
    style.textContent = `
        @keyframes navLinkPulse {
            0% { transform: scale(1); }
            50% { transform: scale(0.95); }
            100% { transform: scale(1); }
        }
        .nav-link-pulse {
            animation: navLinkPulse 0.5s ease;
        }
    `;
    document.head.appendChild(style);
}); 